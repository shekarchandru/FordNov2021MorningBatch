package com.ford.Training.Training_Week_6.Cons;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class MyDAO {
    public MyDAO() {
    }
    public List<String> getCountryDetails(){
        return getCountries();
    }
    public List<String> getCountries(){
        List<String> countries = new ArrayList<String>();
        countries.add("India");
        countries.add("Australia");
        countries.add("USA");
        countries.add("UK");
        countries.add("Japan");
        return countries;
    }
}
