package com.ford.Training.Training_Week_6.Cons;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class MyController {
    private MyService myService;

    @Autowired
    public MyController() {
    }

    @Autowired
    public MyController(MyService myService) {
        this.myService = myService;
    }

    public List<String> getCountriesCTR(){
        return myService.getCountriesSVC();
    }
}
