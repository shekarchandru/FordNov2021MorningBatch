package com.ford.Training.Training_Week_6.Cons;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean
    public MyController myController(MyService myService){
        return new MyController(myService);
    }

    @Bean
    public MyService myService(MyDAO myDAO){
        return new MyService(myDAO);
    }

    @Bean
    public MyDAO myDAO(){
        return new MyDAO();
    }
}
