package com.ford.Training.Training_Week_6.Cons;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MyService {
    MyDAO md;

    @Autowired
    public MyService(MyDAO md) {
        this.md = md;
    }
    public List<String> getCountriesSVC(){
        return md.getCountries();
    }
}
