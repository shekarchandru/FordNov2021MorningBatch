package com.ford.Training.Training_Week_6.AnnotationsCollection;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
public class AppConfig {
    @Bean
    public CollectionBean getCollectionBean(){
        return new CollectionBean();
    }

    @Bean
    public List<String> countries(){
        return Arrays.asList("India","Russia","Japan");
    }

    @Bean
    public Map<String,String> countryPopulation(){
        Map<String,String> countryPop = new HashMap<String,String>();
        countryPop.put("USA","30c");
        countryPop.put("India","20c");
        countryPop.put("France","60c");
        return countryPop;
    }
}
