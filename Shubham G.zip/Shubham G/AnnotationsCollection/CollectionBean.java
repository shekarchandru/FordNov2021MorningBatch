package com.ford.Training.Training_Week_6.AnnotationsCollection;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CollectionBean {
    @Autowired
    List<String> countries = new ArrayList<String>();

    @Autowired
    Map<String,String> countryPopulation = new HashMap<String,String>();

    public List<String> getCountryDetails(){
        return getCountries();
    }

    public List<String> getCountries(){
        return countries;
    }

    public Map<String,String> getCountryPopulationDetails(){
        return getCountryPopulation();
    }

    public Map<String,String> getCountryPopulation(){
        return countryPopulation;
    }
}
