package com.ford.Training.Training_Week_6.AnnotationsCollection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Injector {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        CollectionBean collectionBean = context.getBean(CollectionBean.class);
        System.out.println(collectionBean.getCountryDetails());
        System.out.println(collectionBean.getCountryPopulationDetails());
    }
}
