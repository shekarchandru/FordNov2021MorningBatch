package com.ford.Training.Training_Week_6.Annotations;

public interface Client {
    public void getClientInfo();
}
