package com.ford.Training.Training_Week_6.Annotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ClientServiceInjector {
    public static void main(String[] args) {
        ApplicationContext context;
        boolean flag = false;
        try {
            context = new AnnotationConfigApplicationContext(AppConfig.class);
            Client client = context.getBean("client1",Client.class);
            client.getClientInfo();

            Service service = context.getBean("service1",Service.class);
            String serviceInfo = service.getServiceInfo();
            System.out.println(serviceInfo);
            flag=true;
        }
        catch (Exception ex){
            ex.printStackTrace();
            flag=false;
        }
    }
}
