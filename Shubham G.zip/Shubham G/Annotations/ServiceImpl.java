package com.ford.Training.Training_Week_6.Annotations;

public class ServiceImpl implements Service{
    @Override
    public String getServiceInfo() {
        return "Returning Service Details..";
    }
}
