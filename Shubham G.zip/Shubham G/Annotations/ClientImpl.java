package com.ford.Training.Training_Week_6.Annotations;

public class ClientImpl implements Client{
    Service service;

    public ClientImpl(Service service) {
        this.service = service;
    }

    @Override
    public void getClientInfo() {
        System.out.println("Returning Client Info..");
        String str = service.getServiceInfo();
    }
}
