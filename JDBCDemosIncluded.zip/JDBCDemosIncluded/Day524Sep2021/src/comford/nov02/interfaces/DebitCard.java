package comford.nov02.interfaces;

public interface DebitCard extends Banking {
    public void calculateDCInterest();
    public void checkBalance();
    public void withdrawAmount();
}
