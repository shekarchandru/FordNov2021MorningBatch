package comford.nov02.interfaces;

public interface CreditCard extends Banking,Insurance {

    public void calculateOutstandingAmt();
    public void calculateCCInterest();
    public void calculateRedemptionPoints();

}
