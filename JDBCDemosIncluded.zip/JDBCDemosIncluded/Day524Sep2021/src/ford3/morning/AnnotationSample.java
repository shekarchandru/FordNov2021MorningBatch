package ford3.morning;

import java.util.Date;

public class AnnotationSample extends BaseClass {

    @Override
    @Deprecated
    @SuppressWarnings("unchecked")
    public void display() {
        super.display();
        int score;
        System.out.println("Displaying Derived class..");
        Date date1 = new Date();
        System.out.println("The Date is "+date1.getDate());
        System.out.println("The Month is "+date1.getMonth());
        System.out.println("The Year is "+date1.getYear());
    }
    //1900
    public static void main(String[] args)
    {
        AnnotationSample aSample = new AnnotationSample();
        aSample.display();


    }

}
