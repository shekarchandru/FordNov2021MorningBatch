package ford3.morning;


import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD,ElementType.TYPE})
@interface SampleAnnotation
{
    int price();
    String city();
    String address();
}
public class CustomAnnotation {

    @SampleAnnotation(price=100,city="Bangalore",address="RTNagar")
    public void display()
    {
        System.out.println("Display for annotated Method....");
    }

    public static void main(String[] args) {
        CustomAnnotation customAnnotation = new CustomAnnotation();
        try {
            Method method =  customAnnotation.getClass().getMethod("display");
             SampleAnnotation sampleAnnotation =   method.getAnnotation(SampleAnnotation.class);
            System.out.println("The Price of the Product is "+sampleAnnotation.price());
            System.out.println("The Address to which the Product info is to be sent "+sampleAnnotation.address());
            System.out.println("The City to which the details are to be sent is "+sampleAnnotation.city());
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }
}
