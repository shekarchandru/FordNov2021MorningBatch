package ford3.morning.jdbc.client;

import ford3.morning.jdbc.employeedbmgmt.EmployeeDBManager;

public class EmployeeDataClient {
    public static void main(String[] args) {
        EmployeeDBManager edbMgr = new EmployeeDBManager();
        edbMgr.displayMainMenu();
    }

}
