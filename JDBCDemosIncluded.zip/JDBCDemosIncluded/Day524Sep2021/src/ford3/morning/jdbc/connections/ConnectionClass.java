package ford3.morning.jdbc.connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionClass {
    Connection con;
    public Connection getMyConnection() {
        String url = "jdbc:mysql://localhost:3306/FordMorn";
        String user = "root";
        String password = "MySQL_@123456";
        try {
            //Step 1 : Load Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Step2 Establish Connection
            con = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
        }
        return con;
    }
}
