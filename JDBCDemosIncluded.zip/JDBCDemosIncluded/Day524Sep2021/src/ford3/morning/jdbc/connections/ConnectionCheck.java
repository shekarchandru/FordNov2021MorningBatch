package ford3.morning.jdbc.connections;


import java.sql.*;

public class ConnectionCheck {
    public static void main(String[] args) {
        Connection con;
        Statement stmt;
        ResultSet rs;

        String url="jdbc:mysql://localhost:3306/FordMorn";
        String user = "root";
        String password = "MySQL_@123456";
        try {
            //Step 1 : Load Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Step2 Establish Connection
            con = DriverManager.getConnection(url, user, password);
            //--------------------------------EVERYTHING IS SAME------------------------
            //Step3 Create Statement
            stmt = con.createStatement();
            //Step4 Execute Query
            rs = stmt.executeQuery("select * from Employee");
            System.out.println("Employee Id     Employee Name    Employee Address Employee PHone Employee Salary Tax");
            while (rs.next()) {
                System.out.println(rs.getString(1) + " " +
                        rs.getString(2) + " " +
                        rs.getString(3) + " " +
                        rs.getString(4) + " " +
                        rs.getFloat(5) + " " +
                        rs.getInt(6));

            }
        }
        catch(ClassNotFoundException cnfe)
        {
            cnfe.printStackTrace();
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }
    }
}
