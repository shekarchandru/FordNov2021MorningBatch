package ford3.morning.jdbc.dao;
import ford3.morning.jdbc.connections.ConnectionClass;
import ford3.morning.jdbc.model.Employee;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    Connection myCon;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    ConnectionClass conClass;
    public EmployeeDAO()
    {
        conClass = new ConnectionClass();
        myCon = conClass.getMyConnection();
    }
    public List <Employee> getAllEmployees()
    {
        List <Employee> employees = new ArrayList<Employee>();
        try {
            stmt = myCon.createStatement();
            rs = stmt.executeQuery("select * from Employee");
            while(rs.next())
            {
                Employee e = new Employee();
                String empId = rs.getString(1);

                e.setEmployeeId(empId);
                e.setEmployeeName(rs.getString(2));
                e.setEmployeeAddress(rs.getString(3));
                e.setEmployeePhone(rs.getString(4));
                e.setEmployeeSalary(rs.getFloat(5));
                e.setEmployeeTax(rs.getInt(6));

                employees.add(e);
            }
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }
        return employees;
    }
    public Employee getEmployeeById(String employeeId)
    {
        return new Employee();
    }
    public boolean insertEmployee(Employee employee)
    {
        boolean flag = false;
        return flag;
    }
    public boolean updateEmployee(Employee employee,String employeeId)
    {
        boolean flag = false;
        return flag;
    }
    public boolean deleteEmployee(String employeeId)
    {
        boolean flag = false;
        return flag;
    }



}
