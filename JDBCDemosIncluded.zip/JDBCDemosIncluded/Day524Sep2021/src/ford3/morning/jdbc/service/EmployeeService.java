package ford3.morning.jdbc.service;

import ford3.morning.jdbc.dao.EmployeeDAO;
import ford3.morning.jdbc.model.Employee;

import java.util.ArrayList;
import java.util.List;

public class EmployeeService {
    EmployeeDAO employeeDAO;
    public EmployeeService()
    {
        employeeDAO = new EmployeeDAO();
    }
    public List<Employee> getALlEmployeeRecords()
    {
       return employeeDAO.getAllEmployees();
    }
    public Employee getEmployeeRecordById(String employeeId)
    {
        return employeeDAO.getEmployeeById(employeeId);
    }
    public boolean insertEmployeeRecord(Employee employee)
    {
        return employeeDAO.insertEmployee(employee);
    }
    public boolean updateEmployeeRecord(Employee employee,String employeeId)
    {
        return employeeDAO.updateEmployee(employee,employeeId);
    }
    public boolean deleteEmployeeRecordById(String employeeId)
    {
        return employeeDAO.deleteEmployee(employeeId);
    }
}
