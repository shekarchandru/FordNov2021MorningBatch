package ford3.morning.jdbc.employeedbmgmt;

import ford3.morning.jdbc.model.Employee;
import ford3.morning.jdbc.service.EmployeeService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class EmployeeDBManager {

    String Connection;
    int choice;
    String reply="yes";
    Scanner scan1 ;
    EmployeeService employeeService;
    public EmployeeDBManager()
    {
        scan1 = new Scanner(System.in);
        employeeService = new EmployeeService();
    }

    public void displayMainMenu()
    {
        while(reply.equals("yes") || reply.equals("YES") ||  reply.equals("Yes")){
            System.out.println("----------------------------MAIN MENU----------------------------");
            System.out.println("1. Get All Employees Data");
            System.out.println("2. Get Employee By ID");
            System.out.println("3. Insert Employee Record");
            System.out.println("4. Update Employee");
            System.out.println("5. Delete Employee");
            System.out.println("6. Exit");
            System.out.println("------------------------------------------------------------------");
            System.out.println("Enter Your Choice...");
            choice = scan1.nextInt();
            switch (choice) {
                case 1:
                {
                    System.out.println("Getting ALl Records");
                    List<Employee> employees = new ArrayList<Employee>();
                    employees = employeeService.getALlEmployeeRecords();
                    Iterator <Employee> empIter = employees.iterator();
                    while(empIter.hasNext())
                    {
                        Employee e = empIter.next();
                        System.out.println(e);
                    }
                    break;
                }
                case 2:
                {
                    System.out.println("Getting  Records By ID");
                    break;
                }
                case 3:
                {
                    System.out.println("Inserting Records");
                    break;
                }
                case 4:
                {
                    System.out.println("Updating Records");
                    break;
                }
                case 5:
                {
                    System.out.println("Deleting Records");
                    break;
                }case 6:
                {
                    System.out.println("Exiting");
                   // System.exit(0);
                    break;
                }
                default:
                {
                    System.out.println("Valid Range is 1-6");
                    break;
                }

            }//Switch ending
            System.out.println("Do You Wish To Continue yes/no");
            reply = scan1.next();
        }
        System.out.println("Exiting Main Menu...");// while loop ending
    } // menu function ending



}
