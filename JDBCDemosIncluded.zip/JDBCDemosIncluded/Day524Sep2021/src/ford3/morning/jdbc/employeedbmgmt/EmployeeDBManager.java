package ford3.morning.jdbc.employeedbmgmt;

import ford3.morning.jdbc.model.Employee;
import ford3.morning.jdbc.service.EmployeeService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class EmployeeDBManager {

    String Connection;
    int choice;
    String reply="yes";
    Scanner scan1 ;
    EmployeeService employeeService;
    public EmployeeDBManager()
    {
        scan1 = new Scanner(System.in);
        employeeService = new EmployeeService();
    }

    public void displayMainMenu()
    {
        while(reply.equals("yes") || reply.equals("YES") ||  reply.equals("Yes")){
            System.out.println("----------------------------MAIN MENU----------------------------");
            System.out.println("1. Get All Employees Data");
            System.out.println("2. Get Employee By ID");
            System.out.println("3. Insert Employee Record");
            System.out.println("4. Update Employee");
            System.out.println("5. Delete Employee");
            System.out.println("6. Exit");
            System.out.println("------------------------------------------------------------------");
            System.out.println("Enter Your Choice...");
            choice = scan1.nextInt();
            switch (choice) {
                case 1:
                {
                    System.out.println("Getting ALl Records");
                    List<Employee> employees = new ArrayList<Employee>();
                    employees = employeeService.getALlEmployeeRecords();
                    Iterator <Employee> empIter = employees.iterator();
                    while(empIter.hasNext())
                    {
                        Employee e = empIter.next();
                        System.out.println(e);
                    }
                    break;
                }
                case 2:
                {
                    System.out.println("Getting  Records By ID");
                    String employeeId;
                    System.out.println("Enter the ID of the Employee whose Record you wish to see...");
                    employeeId = scan1.next();
                    Employee employee = employeeService.getEmployeeRecordById(employeeId);
                    System.out.println("The Employee Record for the ID "+employeeId+" is ...");
                    System.out.println(employee);
                    break;
                }
                case 3:
                {
                    System.out.println("Inserting Records");
                    String empId="",empName="",empAddress="",empPhone="";
                    float empSalary=0.0f;
                    int empTax=0;

                    System.out.println("Enter the Id of the Employee ");
                    empId = scan1.next();
                    /*
                    System.out.println("Enter the Name of the Employee");
                    empName = scan1.next();
                    System.out.println("Enter the Address of the Employee");
                    empAddress = scan1.next();
                    System.out.println("Enter the Phone of the Employee");
                    empPhone = scan1.next();
                    System.out.println("Enter the Salary of the Employee");
                    empSalary = scan1.nextFloat();
                    System.out.println("Enter the Tax liability of the Employee");
                    empTax = scan1.nextInt(); */
                    Employee e = acceptData();
                    e.setEmployeeId(empId);
                    if(employeeService.insertEmployeeRecord(e))
                    {
                        System.out.println("Employee Record Inserted Successfully...");
                    }
                    else
                    {
                        System.out.println("Sorry!!! Insertion Failed....");
                    }
                    break;
                }
                case 4:
                {
                    System.out.println("Updating Records");
                    // Displaying Current Records

                    String empId;
                    System.out.println("Enter The Id of The Employee whose Record You Wish to Update ...");
                    empId = scan1.next();
                    Employee eUpdate = employeeService.getEmployeeRecordById(empId);
                    System.out.println("The Current Record of "+empId+" is :");
                    System.out.println(eUpdate);
                    String empName="",empAddress="",empPhone="";
                    float empSalary=0.0f;
                    int empTax=0;
                  /*  String empName,empAddress,empPhone;
                    float empSalary;
                    int empTax;

                    System.out.println("Enter the Name of the Employee");
                    empName = scan1.next();
                    System.out.println("Enter the Address of the Employee");
                    empAddress = scan1.next();
                    System.out.println("Enter the Phone of the Employee");
                    empPhone = scan1.next();
                    System.out.println("Enter the Salary of the Employee");
                    empSalary = scan1.nextFloat();
                    System.out.println("Enter the Tax liability of the Employee");
                    empTax = scan1.nextInt();*/
                    eUpdate = acceptData();
                   // e.setEmployeeId(empId);
                    //Employee e = new Employee(empId,empName,empAddress,empPhone,empSalary,empTax);
                    if (employeeService.updateEmployeeRecord(eUpdate,empId))
                    {
                        System.out.println("Record Updated Successfully for Employee with Id "+empId);
                    }
                    else
                    {
                        System.out.println("Sorry!!! Updation Failed....");
                    }
                    break;
                }
                case 5:
                {
                    System.out.println("Deleting Records");
                    String empId;
                    System.out.println("Enter the Id of the Employee, whose Record You wish to delete..");
                    empId = scan1.next();
                    if(employeeService.deleteEmployeeRecordById(empId))
                    {
                        System.out.println("Record Deleted for the Employee with Id "+empId);
                    }
                    else
                    {
                        System.out.println("Deletion Failed....");
                    }
                    break;
                }case 6:
                {
                    System.out.println("Exiting");
                   // System.exit(0);
                    break;
                }
                default:
                {
                    System.out.println("Valid Range is 1-6");
                    break;
                }

            }//Switch ending
            System.out.println("Do You Wish To Continue yes/no");
            reply = scan1.next();
        }
        System.out.println("Exiting Main Menu...");// while loop ending
    } // menu function ending

    public Employee acceptData()
    {
        String empName,empAddress,empPhone;
        float empSalary;
        int empTax;

        System.out.println("Enter the Name of the Employee");
        empName = scan1.next();
        System.out.println("Enter the Address of the Employee");
        empAddress = scan1.next();
        System.out.println("Enter the Phone of the Employee");
        empPhone = scan1.next();
        System.out.println("Enter the Salary of the Employee");
        empSalary = scan1.nextFloat();
        System.out.println("Enter the Tax liability of the Employee");
        empTax = scan1.nextInt();
        Employee e = new Employee(empName,empAddress,empPhone,empSalary,empTax);
        return e;
    }


}
