package ford4.anoon.jdbc.client;

public class StringCheck {
    public static void main(String[] args) {
        String maxEmpId = "E008";
        String preId,postId;
        preId = maxEmpId.substring(0,1);
        System.out.println("  maxEmpId.substring(0,1) : "+preId);
        postId = maxEmpId.substring(1);
        System.out.println(" maxEmpId.substring(1) "+postId);
    }
}
