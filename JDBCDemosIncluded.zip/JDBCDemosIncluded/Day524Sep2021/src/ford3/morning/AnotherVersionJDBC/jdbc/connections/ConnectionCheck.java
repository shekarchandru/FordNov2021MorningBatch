package ford4.anoon.jdbc.connections;

import java.sql.*;

public class ConnectionCheck {
    public static void main(String[] args) {

        Connection con;
        Statement stmt;
        ResultSet rs;

        String url = "jdbc:mysql://localhost:3306/FordMorn";
        String user="root";
        String password = "MySQL_@123456";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url,user,password);
            stmt = con.createStatement();
            rs = stmt.executeQuery("select * from Employee");
            System.out.println("Employee Id \t EmployeeName \t EmployeeAddress \t EmployeePhone \t EmployeeSalary \t EmployeeTax");
            while(rs.next())
            {
                System.out.println(rs.getString(1)+" \t"+rs.getString(2)+"\t "+rs.getString(3)+" \t "+rs.getString(4)+"\t "+rs.getFloat(5)+"\t "+rs.getInt(6));
            }
        }
        catch(ClassNotFoundException cnfe)
        {
            cnfe.printStackTrace();
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }
    }

}
