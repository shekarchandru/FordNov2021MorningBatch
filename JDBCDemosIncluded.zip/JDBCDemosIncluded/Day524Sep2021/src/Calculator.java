public class Calculator {

    public int add(int num1, int num2) {
        return num1 + num2;
    }

    public int multiply(int num1, int num2) {
        return num1 * num2;
    }

  public int divide(int num1, int num2)  {
        int result=0;
        try {
            result = num1 / num2;
        } catch (ArithmeticException ae) {
            ae.printStackTrace();
            throw ae;
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

        }
        return result;
    } /* */

    public void manipulateArrray()
    {
        int arr[] = new int[5];
        try {
            for (int i = 0; i <= 5; i++) {
                arr[i] = i + 1;
            }
        }
        catch(ArrayIndexOutOfBoundsException aie)
        {
            throw aie;
        }
    }
}









