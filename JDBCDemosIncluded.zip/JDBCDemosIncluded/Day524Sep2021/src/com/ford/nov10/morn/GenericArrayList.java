package com.ford.nov10.morn;

import java.util.ArrayList;
import java.util.Iterator;

public class GenericArrayList {

    ArrayList <Employee> employees;
    boolean flag;

    public GenericArrayList()
    {
        flag = false;
        employees = new ArrayList<Employee>();
        Employee e1 = new Employee("E001","Harsha","RTNagar","9848848848",10000);
        employees.add(e1);
        employees.add(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employees.add(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employees.add(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employees.add(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));
    }
    public boolean displayGenericArrayList()
    {
        Iterator <Employee> empIter = employees.iterator();
        while(empIter.hasNext())
        {
            Employee e = empIter.next();
            System.out.println(e);
        }
        flag = true;
        return flag;
    }
    // Break 11.50 to 12.10----------------

}
