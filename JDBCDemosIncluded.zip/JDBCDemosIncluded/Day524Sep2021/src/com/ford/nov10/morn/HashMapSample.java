package com.ford.nov10.morn;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapSample {

    HashMap<String,Employee> myHashMap;
    boolean flag;

    public HashMapSample()
    {
        flag = false;
        myHashMap = new HashMap<String,Employee>();

        myHashMap.put("E001",new Employee("E001","Harsha","RTNagar","9848848848",10000));
        myHashMap.put("E002",new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        myHashMap.put("E003",new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        myHashMap.put("E004",new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        myHashMap.put("E005",new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));

    }
    public boolean fetchAllValuesOfHashMap()
    {
        Set myKeys = myHashMap.keySet();
        try {
            Iterator<String> keyIter = myKeys.iterator();
            while (keyIter.hasNext()) {
                String myKey = keyIter.next();
                System.out.println("The Hash Map Value for the Key :" + myKey + " is " + myHashMap.get(myKey));
            }
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
