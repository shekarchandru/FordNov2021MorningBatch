package com.ford.nov10.noon;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {

    ArrayList  customers;
    boolean flag;
    public ArrayListSample()
    {
        flag = false;
        customers = new ArrayList();
        Customer c1 = new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1");
        customers.add(c1);
        customers.add(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        customers.add(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        customers.add(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        customers.add(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));

    }
    public boolean fetchCustomersDataFromArrayList()
    {
        //Object
        Iterator custIter1;
        System.out.println("Initial Customer Details are....");

        if(displayCustomers(customers))
        {
            flag = true;
        }


        customers.add(4,new Customer("C006","Rajesh","Koramangala","9834999498",5000.0f,"Product5"));
        System.out.println(" Customer Details After inserting a Customer.at 5thPosition...");
        if(displayCustomers(customers)) {
            flag = true;
        }

        customers.remove(2);
        System.out.println(" Customer Details after Removing at 3 Position");
        if(displayCustomers(customers)) {
            flag = true;
        }

        return flag;
    }
    private boolean displayCustomers(ArrayList customers)
    {
        Iterator custIter;
        System.out.println("Array List Customers are..");
        try {
            custIter = customers.iterator();
            while (custIter.hasNext()) {
                Customer customer = (Customer) custIter.next();
                System.out.println(customer);
            }
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public Customer getCustomerByIndex(int myIndex)
    {
        Customer customer = (Customer) customers.get(myIndex);
        System.out.println(customer);

        return customer;
    }



}
