package com.ford.nov10.noon;

import com.ford.nov10.morn.HashMapSample;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class HashTableSample {

    Hashtable <String,Customer> hashTable;
    boolean flag;

    public HashTableSample()
    {
        flag = false;
        hashTable = new Hashtable<String,Customer>();
        hashTable.put("C001",new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1"));
        hashTable.put("C002",new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        hashTable.put("C003",new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        hashTable.put("C004",new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        hashTable.put("C005",new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));
    }

    public boolean getHashTableValues()
    {
        Enumeration <String> keyEnumer;

       try {
           keyEnumer =  hashTable.keys();
           while (keyEnumer.hasMoreElements()) {
               String myKey = keyEnumer.nextElement();
               System.out.println("The Value for the Key :" + myKey + " In Hash Table is " + hashTable.get(myKey));
           }
           flag = true;
       }
       catch(Exception exc)
       {
           exc.printStackTrace();
           flag = false;
       }
       return flag;
    }
    public boolean getHashTableValuesOnly()
    {
      Collection myCollection =  hashTable.values();

      Iterator <Customer> colIter ;
        System.out.println("The Values in HashTable are..");
        try {
            colIter = myCollection.iterator();
            while (colIter.hasNext()) {
                Customer customer = colIter.next();
                System.out.println(customer);
            }
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public Customer getCustomerByKeyFromHashTable(String key)
    {
        Customer customer = hashTable.get(key);
        System.out.println(customer);
        return customer;
    }
}
