package com.ford.nov10.noon;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

    LinkedList customersLL;
    boolean flag ;

    public LinkedListSample()
    {
        customersLL = new LinkedList();
        flag = false;
        Customer c1 = new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1");
        customersLL.add(c1);
        customersLL.add(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        customersLL.add(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        customersLL.add(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        customersLL.add(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));

    }
    public boolean displayLinkedListElements() {
        Iterator custIter;
        System.out.println("Linked List Customer Details are...");
        customersLL.addFirst(new Customer("C006","Sumesh","Vijayanagar","9534999498",15000.0f,"Product6"));
        customersLL.addLast(new Customer("C007","Manju","KRPuram","9534976498",14000.0f,"Product1"));

        try {
            custIter = customersLL.iterator();
            while (custIter.hasNext()) {
                Customer customer = (Customer) custIter.next();
                System.out.println(customer);
            }
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }

    public boolean displayListCustomersInReverse()
    {
        Iterator custIter ;
        System.out.println("The Customers in Reverse Order in The LinkedList are...");

        try {
            custIter = customersLL.descendingIterator();
            while (custIter.hasNext()) {
                Customer customer = (Customer) custIter.next();
                System.out.println(customer);
            }
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }



}
