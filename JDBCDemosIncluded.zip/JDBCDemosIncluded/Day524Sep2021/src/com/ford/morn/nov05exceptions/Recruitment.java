package com.ford.morn.nov05exceptions;

public class Recruitment {

    private void checkAge(int age) throws InvalidAgeException
    {
        if( (age >= 20) && (age <= 30))
        {
            System.out.println("Valid Age ....Eligible for Recruitment "+age);

        }
        else
        {
            throw new InvalidAgeException("Age to be between 20 to 30 including limits...");
        }

    }
    public boolean scrutinizeAge(int age) throws InvalidAgeException , ArithmeticException
    {
       boolean flag = false;
        System.out.println("About to Check Age....");
        try {
            checkAge(age);
            flag = true;
        }
        catch(InvalidAgeException iae )
        {
            iae.printStackTrace();
            flag = false;
            throw iae;
        }
        System.out.println("Age Check Completed further scrutiny to proceed...");
        return flag;
    }

    public static void main(String[] args)  {

        Recruitment rc = new Recruitment();
        System.out.println("Recruitment Process Started....");
     try {
            rc.scrutinizeAge(26);
            rc.scrutinizeAge(22);
            rc.scrutinizeAge(35);
            rc.scrutinizeAge(21);
           rc.scrutinizeAge(23);
    }
        catch(InvalidAgeException iae)
        {
            iae.printStackTrace();
        }
        System.out.println("Recruitment Process Proceeds further.....");
    }



}
