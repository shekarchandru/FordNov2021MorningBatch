package com.ford.morn.nov05exceptions;

public class Calculator {
    public int calculateDividend(int numerator,int denominator)
    {
        int result=0;

            System.out.println("Inside the Calculator function...");
            try {
                result = (numerator / denominator);
            }
           catch(ArithmeticException ae)
            {
                ae.printStackTrace();
            }  /* */
            finally
            {
                System.out.println("We are anyways here..");
            }
            System.out.println("The Result is " + result);
            System.out.println("We finished Calculation..");

        return result;
    }

    public static void main(String[] args) {
        Calculator calci = new Calculator();
        System.out.println("We are about to call Calculator Method...");
    /*try { */
        calci.calculateDividend(200, 100);
        calci.calculateDividend(200, 50);
        calci.calculateDividend(200, 0);
        calci.calculateDividend(200, 100);
        calci.calculateDividend(200, 10);
   /* }
    catch(ArithmeticException ae)
    {
        ae.printStackTrace();
    }*/
        System.out.println("We finished Calculation..");
    }
}
