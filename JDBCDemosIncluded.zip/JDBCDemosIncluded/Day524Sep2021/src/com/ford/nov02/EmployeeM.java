package com.ford.nov02;

public class EmployeeM {

    double grossSalary,nettSalary;
    // Overloaded Functions......
    public void calculateSalary(int basic,int hra,int cca,double allowances)
    {
        grossSalary = (basic + hra + cca )+ ((allowances / 100) * basic) ;
        System.out.println("The Gross Salary is "+grossSalary);
    }
    public void calculateSalary(int basic,int hra,int cca,double allowances,double deductions)
    {
        nettSalary = ((basic + hra + cca )+ ((allowances / 100) * basic))- ((deductions / 100) * basic) ;
        System.out.println("The Nett Salary is "+nettSalary);
    }
    public void calculateSalary(int basic,int hra,int cca,double allowances,double deductions,String empName)
    {
        grossSalary = (basic + hra + cca )+ ((allowances / 100) * basic) ;
        nettSalary = ((basic + hra + cca )+ ((allowances / 100) * basic))- ((deductions / 100) * basic) ;
        System.out.println("Employee "+empName+" Draws a Gross of "+grossSalary+" And his Nett Salary is "+nettSalary);
    }

    public static void main(String[] args) {
        EmployeeM employee1 = new EmployeeM();
        // Invoking Overloaded Functions
        employee1.calculateSalary(2000,450,320,12.4);
        employee1.calculateSalary(1000,350,250,12.5,8.5);
        employee1.calculateSalary(2000,450,320,12.4,8.3,"Harsha");


    }
}
