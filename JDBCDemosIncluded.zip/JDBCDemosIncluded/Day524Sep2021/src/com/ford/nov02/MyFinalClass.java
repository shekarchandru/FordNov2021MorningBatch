package com.ford.nov02;

public final class MyFinalClass {
    public final void finalMethod1()
    {
        System.out.println("This is final method ONE not to be overridden..");
    }
    public void finalMethod2()
    {
        System.out.println("This is final method TWO not to be overridden..");
    }
    public void finalMethod2(int x,int y)
    {
        System.out.println("The sum is "+(x+y));
    }
    // public abstract void myAbstractMethod();
}
