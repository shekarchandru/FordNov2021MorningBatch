package com.ford.nov02;

public interface Interface1 {
   default void method1()
    {
        System.out.println("displaying Function");
    }  /* */

}
class Test implements Interface1{
  @Override
    public void method1()
    {
       Interface1.super.method1();
        System.out.println("Displaying Method1 ..");

    } /* */

    public static void main(String[] args) {

        Interface1 inter1 = new Test();
        inter1.method1();
    }

}
