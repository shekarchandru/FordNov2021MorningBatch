package com.ford.java8;
interface MyInterface
{
    public void display();
}
interface MyInterface2
{
    public void calculate(int quantity,int pricePerUnit);
}
interface Customer
{
    public void calculate(int quantity,int pricePerUnit);

}
interface DiscountedCustomer
{
    public double calculateInvoiceAmount(int quantity,int pricePerUnit);
}
interface SalesData
{
    public void processSalesOrder(int price,int quantity,DiscountedCustomer customer);
}
public class SampleLambdaExpression {
    public static void main(String[] args) {

        MyInterface myInterface1 = () ->{
            System.out.println("Welcome to Functional Interfaces...");
            System.out.println("Functional Interfaces are Interfaces with 1 abstract Method...");
            System.out.println("Lambda Expressions implement Functional Interface methods...");
            System.out.println("Lambda Expressions focuses on Implementation of Functional Programming in Java...");
        };
        myInterface1.display();
        System.out.println("--------------------");
        MyInterface2 myInterface2 = (int quantity,int pricePerUnit)->{

            int invoiceAmount = quantity * pricePerUnit;
            System.out.println("The Total Purchase Value is "+invoiceAmount);
        };
        myInterface2.calculate(200,1000);
        System.out.println("--------------------");
        MyInterface2 myinterface21 = (int quantity,int pricePerUnit)->{
            int invoiceAmt = quantity * pricePerUnit;
            if(invoiceAmt >= 200000)
            {
                System.out.println("The Invoice Amt is Liable for Sales Tax...");
            }
            else
            {
                System.out.println("The Invoice Amt is eligible for Tax Benefits...");
            }
        };
        myinterface21.calculate(200,1000);
        myinterface21.calculate(200,900);
        System.out.println("--------------------------------");

        DiscountedCustomer dCustomer1 = (int quantity,int pricePerUnit )->{
            int totalInvoiceValue = quantity * pricePerUnit;
            double discountedInvoiceAmt  = totalInvoiceValue - (totalInvoiceValue * 0.1);
            return discountedInvoiceAmt;
        };
        DiscountedCustomer dCustomer2 = (int quantity,int pricePerUnit )->{
            int totalInvoiceValue = quantity * pricePerUnit;
            double discountedInvoiceAmt  = totalInvoiceValue - (totalInvoiceValue * 0.2);
            return discountedInvoiceAmt;
        };

        SalesData salesData1 = (int quantity,int pricePerUnit,DiscountedCustomer discCustomer) ->
        {
            int invoiceAmount = quantity * pricePerUnit;
            System.out.println("The Actual Invoice Amount is "+invoiceAmount);
            double finalInvoiceAmount = discCustomer.calculateInvoiceAmount(quantity,pricePerUnit);
            System.out.println("the Final Discounted Amount is "+finalInvoiceAmount);
        };
        SalesData salesData1GST = (int quantity,int pricePerUnit,DiscountedCustomer discCustomer) ->
        {
            int invoiceAmount = (quantity * pricePerUnit);
            int gstInvoiceAmt = (quantity * pricePerUnit)+18;
            System.out.println("The Actual Invoice Amount with GST is "+gstInvoiceAmt);
            double finalInvoiceAmount = discCustomer.calculateInvoiceAmount(quantity,pricePerUnit);
            System.out.println("the Final Discounted Amount is "+finalInvoiceAmount);
        };
        salesData1.processSalesOrder(100,1000,dCustomer1);
        salesData1GST.processSalesOrder(100,1000,dCustomer2);

    }

}
