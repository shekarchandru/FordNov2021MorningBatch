package com.ford.nov12.anoon.functional;

public interface MyInterface2 {
    public void calculate(int a,int b);
}
