package com.ford.javas;
interface MyInterface
{
    public void display();
}
interface MyInterface2
{
    public void calculate(int a,int b);
}
interface Customer
{
    public void calculateInvoiceAmt(int qty,int price);
}
interface NewCustomer
{
    public double calculateInvoiceAmt(int qty, int price);
}
interface SalesData
{
    public void processOrder(int qty,int price,NewCustomer c);

}

public class LambdExpressions {

    public static void main(String[] args)
    {
        NewCustomer cust1 = (int qty,int price) -> {
            int totValue = qty * price;
            double finalSaleValue = totValue - (totValue * 0.1 );
            return finalSaleValue;
        };
        NewCustomer cust2 = (int qty,int price) -> {
            int totValue = qty * price;
            double finalSaleValue = totValue - (totValue * 0.2 );
            return finalSaleValue;
        };
        SalesData sd1 = (int q,int p,NewCustomer nc) ->{
            int actualPrice =  q * p;
            System.out.println("the Actual Invoice amt is "+actualPrice);
            double finalPrice = nc.calculateInvoiceAmt(p,q) ;
            System.out.println("the final Price for cust1 "+finalPrice);
        };
        SalesData sd2 = (int q,int p,NewCustomer nc) ->{
            int actualPrice =  q * p;
            System.out.println("the Actual Invoice amt is "+actualPrice);
            double finalPrice = nc.calculateInvoiceAmt(p,q) ;
            System.out.println("the final Price for cust2 "+finalPrice);
        };
        sd1.processOrder(100,1000,cust1);
        sd1.processOrder(100,1000,cust2);
    }


}
