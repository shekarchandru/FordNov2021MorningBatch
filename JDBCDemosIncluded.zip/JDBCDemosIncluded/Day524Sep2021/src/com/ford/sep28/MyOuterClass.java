package com.ford.sep28;
class AnotherClass
{
   // MyInnerClass mic = new MyInnerClass();
}
public class MyOuterClass {

    int score;

    public void displayOuterFunction()
    {
        score = 85;
        System.out.println("The score is "+score);
        MyInnerClass mic = new MyInnerClass();
        System.out.println("The Capacity of the inner Class Engine is "+mic.capacity);

        mic.displayEngineCapacity();
    }
         class MyInnerClass
        {
            int capacity;
            public void displayEngineCapacity()
            {
                capacity = 1000;
                score = 90;
                System.out.println("The Engine Capacity is "+capacity);
                System.out.println("the score of my Container is "+score);
            }

        }



    public static void main(String[] args) {

        MyOuterClass moc = new MyOuterClass();
        moc.displayOuterFunction();


    }
}
