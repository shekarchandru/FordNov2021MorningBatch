package com.ford.sep28;

public class ArrayExceptionClass {


    public int getElementByIndex(int[] myArray, int i) {
    int result;
    try {
        result = myArray[i];
    }
    catch(ArrayIndexOutOfBoundsException aie)
    {
        aie.printStackTrace();
        throw aie;
    }
     return result;
    }

    public String getCountryByIndex(String[] countries, int i) {
        String country="";
        try {
                country = countries[i];
            }
        catch(ArrayIndexOutOfBoundsException aie)
        {
            aie.printStackTrace();
        }
        return country;
    }
}
