package com.ford.nov01;

import java.util.Scanner;

public class Furniture {

    Scanner scan1 ;
    /*private*/ protected int length;
    /*private*/ protected int width;
    /*private*/ protected  int height;

    public Furniture() {
        scan1 = new Scanner(System.in);
        length = 2;
        width = 4;
        height = 6;
    }

    public Furniture(int length, int width, int height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

    public Furniture(int length, int width) {
        this.length = length;
        this.width = width;
    }


    /*
* Cosntructors are special methods which have the same names as that of the class Name
* which would be invoked automatically ,when an object is created ,
* Constructors are used to initialize data members and allocate memory for the Object
* */
    public void acceptFurnitureDetails()
    {
        System.out.println("Enter the furniture details...");
        System.out.println("Enter the Length ");
        length = scan1.nextInt();
        System.out.println("Enter the Width ");
        width = scan1.nextInt();
        System.out.println("Enter the Height ");
        height = scan1.nextInt();
    }
    public void displayFurnitureDetails()
    {
        System.out.println("The Furniture details are ");
        System.out.println("The Length is "+length);
        System.out.println("The Width is "+width);
        System.out.println("The Height is "+height);
    }


}
