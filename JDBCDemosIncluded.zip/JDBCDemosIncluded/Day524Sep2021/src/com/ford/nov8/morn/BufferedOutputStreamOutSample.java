package com.ford.nov8.morn;

import java.io.BufferedOutputStream;
import java.io.IOException;

public class BufferedOutputStreamOutSample {
    BufferedOutputStream bos;
    boolean flag = false;
    String str = "We are writing onto Monitor";
    byte myBytes[] = new byte[100];
    public boolean writeToMonitor()
    {
        myBytes = str.getBytes();
        bos = new BufferedOutputStream(System.out);
        try
        {
            flag = true;
            bos.write(myBytes);

            bos.flush();
            System.out.println("We have written successfully onto Monitor thru Buffered Stream...");


            bos.close();

        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;

    }

}
