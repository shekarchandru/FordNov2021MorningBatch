package com.ford.nov8.morn;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderSample {

    FileReader fReader;
    File file1;
    boolean flag = false;
    public boolean readFromCharStream()
    {
        int myChar;
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\Supplier.txt");
       try {
           fReader = new FileReader(file1);
           // Reads character by character until it encounters end of the file...
           System.out.println("Data Read from File is ...");
           while((myChar = fReader.read()) != -1)
           {
               System.out.print((char)myChar);
               flag = true;
           }
           fReader.close();
       }
       catch(FileNotFoundException fnfe)
       {
           fnfe.printStackTrace();
           flag = false;
       }
       catch(IOException ios)
       {
           ios.printStackTrace();
           flag = false;
       }
        return flag;
    }


}
