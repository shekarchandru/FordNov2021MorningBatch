package com.ford.nov8.morn;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamSample {

    FileOutputStream fos;
    File file1;
    String str = "We are writing into Binary Stream...";
    byte myBytes[] = new byte[100];
    boolean flag = false;
    public boolean writeToStream()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\Customer.txt");
       try {
           fos = new FileOutputStream(file1);
           //Converting into BYtes
           myBytes = str.getBytes();
           fos.write(myBytes);
           System.out.println("Written Successfully into Stream..");
           flag = true;
           fos.close();
           fos.flush();
           System.out.println("We finished writing data to file thru stream");
       }
       catch(FileNotFoundException fnfe)
       {
           fnfe.printStackTrace();
           flag = false;
       }
       catch(IOException ioe)
       {
           ioe.printStackTrace();
           flag = false;
       }
       return flag;
    }
}
