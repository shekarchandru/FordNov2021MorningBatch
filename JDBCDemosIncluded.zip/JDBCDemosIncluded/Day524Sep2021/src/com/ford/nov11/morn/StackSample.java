package com.ford.nov11.morn;

import java.util.Iterator;
import java.util.Stack;

public class StackSample {
    Stack<Employee> employeeStack;
    /*
      employeeVector.addElement(new Employee("E001","Harsha","RTNagar","9848848848",10000));
        employeeVector.addElement(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employeeVector.addElement(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employeeVector.addElement(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employeeVector.addElement(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));

     */
    public StackSample()
    {
        employeeStack = new Stack<Employee>();
        employeeStack.push(new Employee("E001","Harsha","RTNagar","9848848848",10000));
        employeeStack.push(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employeeStack.push(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employeeStack.push(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employeeStack.push(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));

    }
    public void popStackElements()
    {
        while(employeeStack.isEmpty() == false)
        {
            Employee employee = employeeStack.pop();
            System.out.println("The popped Element is "+employee);
        }
    }
    public void iterateStackElements()
    {

            Iterator <Employee> empIter = employeeStack.iterator();
            while(empIter.hasNext())
            {
                Employee employee = empIter.next();
                System.out.println(employee);
            }

    }
    public void fetchStackThruRemove(int count)
    {
        if(employeeStack.isEmpty() == false)
        {
            Employee employee = employeeStack.remove(count);
            System.out.println("The Removed Element is "+employee);
        }


    }


    public static void main(String[] args) {
        StackSample stackSample = new StackSample();
        stackSample.popStackElements();
        System.out.println("-----------------------------");
        StackSample stackSample1 = new StackSample();
        stackSample1.iterateStackElements();
        System.out.println("-----------------------------");

        stackSample1.fetchStackThruRemove(3);

    }
}
