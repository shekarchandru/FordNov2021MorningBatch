package com.ford.nov11.morn;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSample {

    Queue <Employee> employeeQueue;

    public QueueSample()
    {
        employeeQueue = new PriorityQueue<Employee>();
        employeeQueue.add(new Employee("E001","Harsha","RTNagar","9848848848",10000));
        employeeQueue.add(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employeeQueue.add(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employeeQueue.add(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employeeQueue.add(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));

    }
    public void deQueueElements()
    {
        while(employeeQueue.isEmpty() == false)
        {
            Employee employee = employeeQueue.remove();
            System.out.println(employee);
        }
    }
    public void deQueueElementsThruPoll()
    {
        while(employeeQueue.isEmpty() == false)
        {
            Employee employee = employeeQueue.poll();
            System.out.println(employee);
        }
    }
    public void deQueueThruIterator()
    {
        Iterator <Employee> empIter = employeeQueue.iterator();
        while(empIter.hasNext())
        {
            Employee employee = empIter.next();
            System.out.println(employee);
        }
    }

    public static void main(String[] args) {
        QueueSample queueSample = new QueueSample();
        queueSample.deQueueElements();
        System.out.println("--------------------");
        QueueSample queueSample1 = new QueueSample();
        queueSample1.deQueueThruIterator();
        System.out.println("--------------------");
        queueSample1.deQueueElementsThruPoll();
    }
}
