package com.ford.nov11.morn;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class VectorSample {

    Vector <Employee> employeeVector;
    boolean flag;
    public VectorSample()
    {
        flag = false;
        employeeVector = new Vector<Employee>(5,8);
        employeeVector.addElement(new Employee("E001","Harsha","RTNagar","9848848848",10000));
        employeeVector.addElement(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employeeVector.addElement(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employeeVector.addElement(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employeeVector.addElement(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));

    }
    public boolean fetchElementsFromVectorThruEnumeration()
    {

        Enumeration <Employee> eVecEnum;
        System.out.println("The Vector elements accessed thru Enumeration are ...");

        try {
            eVecEnum = employeeVector.elements();
            while (eVecEnum.hasMoreElements()) {
                Employee employee = eVecEnum.nextElement();
                System.out.println(employee);
            }
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean fetchElementsFromVectorThruIterator()
    {
        Iterator <Employee> eVecIter;
        System.out.println("Initial Capacity :"+employeeVector.capacity());
        System.out.println("Initial Size :"+employeeVector.size());
                employeeVector.add(new Employee("E006","Raghu Ram","Jayanagar","8325848848",13000));
                employeeVector.add(new Employee("E007","Darshan","Vijayanagar","8315848848",14000));
            //    employeeVector.add(new Employee("E008","Kishore","Malleswaram","8015848848",15000));
        System.out.println(" Capacity after adding 3 elements :"+employeeVector.capacity());
        System.out.println("Current  Size :"+employeeVector.size());
        System.out.println("The Vector elements accessed thru Iterator are ...");
        try
        {
            eVecIter = employeeVector.iterator();
            while(eVecIter.hasNext())
            {
                Employee employee = eVecIter.next();
                System.out.println(employee);
            }
            flag = true;

        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean fetchElementsFromVectorThruIteratorNew()
    {
        Iterator <Employee> eVecIter;
        employeeVector.addElement(new Employee("E008","Sumesh","Malleswaram","8315458848",15000));
        employeeVector.insertElementAt(new Employee("E008","Sumesh","Malleswaram","8315458848",15000),4);
        System.out.println("Elements after addition...");
        try
        {
            eVecIter = employeeVector.iterator();
            while(eVecIter.hasNext())
            {
                Employee employee = eVecIter.next();
                System.out.println(employee);
            }
            flag = true;

        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        employeeVector.removeElementAt(3);
        System.out.println("Elements after removal...");
        try
        {
            eVecIter = employeeVector.iterator();
            while(eVecIter.hasNext())
            {
                Employee employee = eVecIter.next();
                System.out.println(employee);
            }
            flag = true;

        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        Employee employeeAt5 = employeeVector.get(4);
        System.out.println("Employee at  5th Position "+employeeAt5);
        return flag;
    }

}
