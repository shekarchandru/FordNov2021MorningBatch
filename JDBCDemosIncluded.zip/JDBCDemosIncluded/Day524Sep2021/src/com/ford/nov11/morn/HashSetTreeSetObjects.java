package com.ford.nov11.morn;

import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetObjects {

    TreeSet <Employee> employeeTreeSet;

    public HashSetTreeSetObjects()
    {
        employeeTreeSet = new TreeSet<Employee>();
        employeeTreeSet.add(new Employee("E001","Harsha","RTNagar","9848848848",10000));
        employeeTreeSet.add(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employeeTreeSet.add(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employeeTreeSet.add(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employeeTreeSet.add(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));

    }
    public void displayTreeSetObjects()
    {
        Iterator <Employee> empIter = employeeTreeSet.iterator();
        while(empIter.hasNext())
        {
            Employee employee = empIter.next();
            System.out.println(employee);
        }
    }

    public static void main(String[] args) {
        HashSetTreeSetObjects hstsObject = new HashSetTreeSetObjects();
        hstsObject.displayTreeSetObjects();
    }
}
