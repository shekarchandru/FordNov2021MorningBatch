package com.ford.nov11.noon;

import java.util.*;

public class TreeMapSample {

    TreeMap <String,Customer> treeMap;
    boolean flag;
    public TreeMapSample()
    {
        flag = false;
        treeMap = new TreeMap <String,Customer> ();
        treeMap.put("C003",new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        treeMap.put("C005",new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));
        treeMap.put("C001",new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1"));
        treeMap.put("C002",new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        treeMap.put("C004",new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));

    }
    /* Hashtable ht = new Hashtable();
       ht.keys() ht.keySet() ht.entrySet() */
      /*  HashMap hm = new HashMap();
        hm.keySet() hm.entrySet() */
        /*
        hashTable keys - enumeration- can be enumerated upon
        hashMap keySet - set of Keys - can be Iterated upon
        treemap entrySet - set of entries - Entry <String,Customer > for eg.
         */
    public boolean fetchTreeMapObjectsThruEntrySet()
    {
        Set<Map.Entry<String, Customer>> myEntrySet;
        try {
            myEntrySet = treeMap.entrySet();
            Iterator<Map.Entry<String, Customer>> myEntries = myEntrySet.iterator();
            while(myEntries.hasNext())
            {
                Map.Entry <String,Customer> entry = myEntries.next();
                String key = entry.getKey();
                Customer customer = entry.getValue();
                System.out.println("The Value for the Key "+key+" is "+customer);
            }
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }


}
