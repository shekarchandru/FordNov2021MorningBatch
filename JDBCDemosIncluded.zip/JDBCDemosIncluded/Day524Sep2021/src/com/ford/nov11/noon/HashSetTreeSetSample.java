package com.ford.nov11.noon;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {
    HashSet <String> hSet;
    TreeSet <String> tSet;

    public HashSetTreeSetSample()
    {
        hSet = new HashSet<String>();
        tSet = new TreeSet<String>();
    }
    public void populateHashSet()
    {
        hSet.add("Faridabad");
        hSet.add("Chandigarh");
        hSet.add("Ernakulam");
        hSet.add("Ahmedabad");
        hSet.add("Hyderabad");
        hSet.add("Bangalore");
    }
    public void populateTreeSet()
    {
        tSet.add("Faridabad");
        tSet.add("Chandigarh");
        tSet.add("Ernakulam");
        tSet.add("Ahmedabad");
        tSet.add("Hyderabad");
        tSet.add("Bangalore");
    }
    public void fetchHashSetObjects()
    {
        Iterator <String> hsIter = hSet.iterator();
        while(hsIter.hasNext())
        {
            String city = hsIter.next();
            System.out.println("City In HashSet is "+city);
        }

    }
    public void fetchTreeSetObjects()
    {
        Iterator <String> tsIter = tSet.iterator();
        while(tsIter.hasNext())
        {
            String city = tsIter.next();
            System.out.println("City In TreeSet is "+city);
        }
    }

    public static void main(String[] args) {
        HashSetTreeSetSample hstsSample = new HashSetTreeSetSample();
        hstsSample.populateHashSet();
        hstsSample.fetchHashSetObjects();
        System.out.println("-----------------");
        hstsSample.populateTreeSet();
        hstsSample.fetchTreeSetObjects();
    }
}
