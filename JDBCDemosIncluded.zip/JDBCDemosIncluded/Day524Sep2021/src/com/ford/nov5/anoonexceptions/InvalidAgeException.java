package com.ford.nov5.anoonexceptions;

public class InvalidAgeException extends Exception {
    String errMessage;
    public InvalidAgeException(String errMessage)
    {
        this.errMessage = errMessage;
    }

    @Override
    public String toString() {
        return "InvalidAgeException{" +
                "errMessage='" + errMessage + '\'' +
                '}';
    }
}
