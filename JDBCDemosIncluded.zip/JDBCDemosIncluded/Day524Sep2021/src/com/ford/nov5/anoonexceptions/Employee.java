package com.ford.nov5.anoonexceptions;

public class Employee {
    String employeeId;
    String employeeName;
    String employeeAddress;
    String employeePhone;
    float employeeSalary;

    public Employee() {
    }

    public Employee(String employeeId, String employeeName, String employeeAddress, String employeePhone, float employeeSalary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeeAddress = employeeAddress;
        this.employeePhone = employeePhone;
        this.employeeSalary = employeeSalary;
    }

    public static void main(String[] args) {
        Employee employee = new Employee("E001","Harsha","RTNagar","9499499494",1000.0f);
        System.out.println(employee);
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId='" + employeeId + '\'' +
                ", employeeName='" + employeeName + '\'' +
                ", employeeAddress='" + employeeAddress + '\'' +
                ", employeePhone='" + employeePhone + '\'' +
                ", employeeSalary=" + employeeSalary +
                '}';
    }
}
