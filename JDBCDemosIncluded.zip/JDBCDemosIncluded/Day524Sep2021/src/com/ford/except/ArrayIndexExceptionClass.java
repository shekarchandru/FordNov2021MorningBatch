package com.ford.except;

public class ArrayIndexExceptionClass {

    public String getValueFromIndex(String[] arrStr,String index)
    {
        try
        {
            return arrStr[Integer.parseInt(index)];
        }
        catch(IndexOutOfBoundsException ioe)
        {
            ioe.printStackTrace();
            throw ioe;
        }
        catch (NumberFormatException nfe)
        {
            nfe.printStackTrace();
            throw nfe;
        }

    }

}
