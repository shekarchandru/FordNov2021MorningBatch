package com.ford.except;


public class ConstructorOverloading {
    int x,y;

    public ConstructorOverloading(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public void display()
    {
        System.out.println("The value of x "+x+" and Y is "+y);
    }
}
