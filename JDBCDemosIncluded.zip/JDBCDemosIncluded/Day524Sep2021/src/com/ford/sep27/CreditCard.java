package com.ford.sep27;

public interface CreditCard {

        public void calculateOutstanding();
        public void calculateInterest();
}
