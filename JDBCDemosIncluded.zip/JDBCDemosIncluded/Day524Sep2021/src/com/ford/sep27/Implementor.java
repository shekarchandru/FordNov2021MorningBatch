package com.ford.sep27;

public class Implementor {

    public void callParser(Parser p,String fileType)
    {
        p.parseFile(fileType);
    }

}
