package com.ford.sep27;

public interface Taxation {
    public void calculateTaxLiability();
}
