package com.ford.sep27;

public abstract class Parser {
    public abstract void parseFile(String fileType);
    public void displayMethod()
    {
        System.out.println("Displaying Abstract Class Method..");
    }
}
