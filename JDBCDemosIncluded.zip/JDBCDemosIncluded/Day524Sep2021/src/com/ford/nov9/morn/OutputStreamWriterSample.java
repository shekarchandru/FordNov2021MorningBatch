package com.ford.nov9.morn;

import java.io.*;

public class OutputStreamWriterSample {
    BufferedWriter bWriter;
    boolean flag;
    File file1;
    String str = "We are converting this String to Bytes...";
    public boolean writeCharsToBytes()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\eCustomers.txt");

        try {
            bWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file1)));
            bWriter.write(str);
            System.out.println("We have converted chars to bytes successfully and written to file...");
            flag = true;
            bWriter.flush();
            bWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            flag = false;
        } catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
