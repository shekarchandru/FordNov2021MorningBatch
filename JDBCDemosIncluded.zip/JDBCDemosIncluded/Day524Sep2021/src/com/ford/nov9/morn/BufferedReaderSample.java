package com.ford.nov9.morn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderSample {
    BufferedReader bReader;
    File file1;
    boolean flag = false;
    String str;
    public boolean readFromCharFileThruBuffer()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\Student.txt");
        try {
            bReader = new BufferedReader(new FileReader(file1));
            str = bReader.readLine();
            System.out.println("The Data Read from file is "+str);
            bReader.close();
            flag = true;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;

    }

}
