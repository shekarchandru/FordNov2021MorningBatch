package com.ford.nov9.morn;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationSample {

    ObjectOutputStream opStream;
    File file1;
    boolean flag = true;
    public boolean serializeObject()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\eEmployees.txt");
        try {
            opStream = new ObjectOutputStream(new FileOutputStream(file1));
            Employee[] employees = new Employee[4];
           /* for(int i=0;i<4;i++)
            {
                employees[i] = new Employee();
            }*/
            employees[0] = new Employee("E001","Harsha","RTNagar","9849499493",10000);
            employees[1] = new Employee("E002","Suman","Koramangala","9846579493",12000);
            employees[2] = new Employee("E003","Johnson","Vijayanagar","9849497683",14000);
            employees[3] = new Employee("E004","Keerthi","Malleswaram","9823499493",16000);

            opStream.writeObject(employees);
            opStream.flush();
            opStream.close();
            flag = true;
            System.out.println("Serialized Array Of Objects successfully...");
        } catch (IOException e) {
            e.printStackTrace();
            flag = false;
        }
    return flag;
    }
}
