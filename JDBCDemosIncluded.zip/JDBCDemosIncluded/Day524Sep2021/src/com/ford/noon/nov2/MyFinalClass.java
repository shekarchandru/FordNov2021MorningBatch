package com.ford.noon.nov2;

public final class MyFinalClass {

    public final void method1()
    {
        System.out.println("Displaying Final Method1 ");
    }
    public void method2()
    {
        System.out.println("Displaying Final Method2 ");
    }
}
