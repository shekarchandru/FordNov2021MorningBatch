package com.ford.noon.nov2.interfaces;

public interface Banking {
    public void createAccount();
    public void closeAccount();

}
