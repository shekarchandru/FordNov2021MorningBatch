package com.ford.noon.nov2.interfaces;

public class MyAccountNew implements CreditCard,DebitCard{

    @Override
    public void createAccount() {
        System.out.println("Account Created Successfully...");
    }

    @Override
    public void closeAccount() {
        System.out.println("Account Closed Successfully...");
    }

    @Override
    public void calculateCCInterest() {
        System.out.println("Credit Card Interest Calcuated Successfully...");
    }

    @Override
    public void calculateRedemptionPoints() {
        System.out.println("Calculated Redemption Points Of CCard Successfully...");
    }

    @Override
    public void calculateOutStanding() {
        System.out.println("Calculated OutStanding of CCard Successfully...");
    }

    @Override
    public void checkBalance() {
        System.out.println("Checked Balance  Successfully and Balance is...");
    }

    @Override
    public void withdrawAmt() {
        System.out.println("Amt withdrawn is ...");
    }

    @Override
    public void depositAmt() {
        System.out.println("Account Deposited with an Amt of ...");
    }

    @Override
    public void createPolicy() {
        System.out.println("Policy Created Successfully...");
    }

    @Override
    public void terminatePolicy() {
        System.out.println("Policy Terminated Successfully...");
    }

    @Override
    public void calculatePremium() {
        System.out.println("Calculated Premium  Successfully...");
    }
}
