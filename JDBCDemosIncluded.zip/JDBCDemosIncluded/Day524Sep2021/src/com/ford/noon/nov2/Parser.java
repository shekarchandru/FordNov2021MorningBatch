package com.ford.noon.nov2;

public abstract class Parser {

    public abstract void parseFile(String fileType);

    public void displayFileContents()
    {
        System.out.println("The Contents of the file are...");
    }


}
