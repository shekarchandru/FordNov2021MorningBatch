package com.ford.noon.nov2;

public class XMLParser extends Parser{

    @Override
    public void parseFile(String fileType) {
        System.out.println("Finished Parsing of "+fileType);
    }
}
