package com.ford2.setter.noon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentSubjInjector {
    ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/StudentSubjectContext.xml");
    boolean flag = false;
    public boolean injectStudent1()
    {
        try
        {
            Student student1 = (Student)context.getBean("student1");
            student1.displayStudentDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectStudent2()
    {
        try
        {
            Student student2 = (Student)context.getBean("student2");
            student2.displayStudentDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
