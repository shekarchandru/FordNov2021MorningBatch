package com.ford2.setter.noon;

public class AppraisalReport {

    String appraisalId;
    String reportId;
    String grade;
    String recommendedHike;

    public String getAppraisalId() {
        return appraisalId;
    }

    public void setAppraisalId(String appraisalId) {
        this.appraisalId = appraisalId;
    }

    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getRecommendedHike() {
        return recommendedHike;
    }

    public void setRecommendedHike(String recommendedHike) {
        this.recommendedHike = recommendedHike;
    }

    @Override
    public String toString() {
        return "AppraisalReport{" +
                "appraisalId='" + appraisalId + '\'' +
                ", reportId='" + reportId + '\'' +
                ", grade='" + grade + '\'' +
                ", recommendedHike='" + recommendedHike + '\'' +
                '}';
    }
}
