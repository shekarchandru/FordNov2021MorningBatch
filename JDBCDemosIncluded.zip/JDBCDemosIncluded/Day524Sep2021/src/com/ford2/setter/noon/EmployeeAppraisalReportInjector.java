package com.ford2.setter.noon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeAppraisalReportInjector {
    ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/EmployeeAppraisalContext.xml");
    boolean flag = false;
    public boolean injectEmployee1()
    {
        try
        {
            Employee employee1 = (Employee) context.getBean("employee1");
            employee1.displayEmployeeDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectEmployee2()
    {
        try
        {
            Employee employee2 = (Employee) context.getBean("employee2");
            employee2.displayEmployeeDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }


}
