package com.ford2.setter.noon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerInjector {
    ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/CustomerContext1.xml");
    boolean flag = false;
    public boolean injectSetterBasedCustomer1()
    {
        try
        {
            Customer customer1 = (Customer)context.getBean("customer1");
            customer1.displayCustomerDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectSetterBasedCustomer2()
    {
        try
        {
            Customer customer2 = (Customer)context.getBean("customer2");
            customer2.displayCustomerDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
