package com.ford1.springcorenoon;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class QuizMap {

    String quizId;
    String topic;
    String question;
    Map <User,Answer> answersByUsers;

    public QuizMap() {
    }

    public QuizMap(String quizId, String topic, String question, Map<User, Answer> answersByUsers) {
        this.quizId = quizId;
        this.topic = topic;
        this.question = question;
        this.answersByUsers = answersByUsers;
    }
    public void displayQuizMapDetails()
    {
        System.out.println("The Quiz Details are...");
        System.out.println("Quiz Id :"+quizId);
        System.out.println("Topic of the Quiz is :"+topic);
        System.out.println("Question is :"+question);
        System.out.println("Answers Given By the Various users are as follows...");
        Set <User> userKeySet = answersByUsers.keySet();
        Iterator <User> userKeyIter = userKeySet.iterator();
        while(userKeyIter.hasNext())
        {
            User userKey = userKeyIter.next();
            System.out.println("The Answer Provided By the User :"+userKey+" is : "+answersByUsers.get(userKey));
        }

    }
}
