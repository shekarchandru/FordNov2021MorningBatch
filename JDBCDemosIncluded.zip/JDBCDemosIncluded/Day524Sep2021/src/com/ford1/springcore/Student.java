package com.ford1.springcore;

public class Student {
    String studentId;
    String studentName;
    Address studAddress;
    int score1;
    int score2;

    public Student() {
    }

    public Student(String studentId, String studentName, Address studAddress, int score1, int score2) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studAddress = studAddress;
        this.score1 = score1;
        this.score2 = score2;
    }
    public void displayStudentDetails()
    {
        System.out.println("Student Details are ...");
        System.out.println("Student Id :"+studentId);
        System.out.println("Student Name :"+studentName);
        System.out.println("Student Address :"+studAddress);
        System.out.println("Student Score1 :"+score1);
        System.out.println("Student Score2 :"+score2);
    }
}
