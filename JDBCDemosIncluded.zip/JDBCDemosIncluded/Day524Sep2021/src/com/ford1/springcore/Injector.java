package com.ford1.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Injector {

    public boolean injectCustomer()
    {
        boolean flag = false;
        try
        {
            ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/ApplicationContext.xml");
            Customer customer = (Customer)context.getBean("customer1");
            customer.displayCustomerDetails();
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
            return flag;

    }
    public boolean injectCustomer2()
    {
        boolean flag = false;
        try
        {
            ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/ApplicationContext.xml");
            Customer customer2 = (Customer)context.getBean("customer2");
            customer2.displayCustomerDetails();
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectCustomer3()
    {
        boolean flag = false;
        try
        {
            ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/ApplicationContext.xml");
            Customer customer3 = (Customer)context.getBean("customer3");
            customer3.displayCustomerDetails();
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectCustomer4()
    {
        boolean flag = false;
        try
        {
            ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/ApplicationContext.xml");
            Customer customer4 = (Customer)context.getBean("customer4");
            customer4.displayCustomerDetails();
            flag = true;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/ApplicationContext.xml");
        Customer customer = (Customer)context.getBean("customer1");
        customer.displayCustomerDetails();
    }
}
