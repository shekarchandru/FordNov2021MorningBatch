package com.ford1.springcore;

public class AnswerN {

    String ansId;
    String answer;

    public AnswerN() {
    }

    public AnswerN(String ansId, String answer) {
        this.ansId = ansId;
        this.answer = answer;
    }

    @Override
    public String toString() {
        return "AnswerN{" +
                "ansId='" + ansId + '\'' +
                ", answer='" + answer + '\'' +
                '}';
    }
}
