package com.ford1.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuestionAnsInjector {
    ApplicationContext context;
    public boolean injectQuestAns1()
    {
        boolean flag = false;
        try
        {
            context = new ClassPathXmlApplicationContext("contextfiles/ApplicationContext2.xml");
            Question question1 = (Question)context.getBean("quest1");
            question1.displayQuestionAndAnswers();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectQuestAns2()
    {
        boolean flag = false;
        try
        {
            context = new ClassPathXmlApplicationContext("contextfiles/ApplicationContext2.xml");
            Question question2 = (Question)context.getBean("quest2");
            question2.displayQuestionAndAnswers();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
