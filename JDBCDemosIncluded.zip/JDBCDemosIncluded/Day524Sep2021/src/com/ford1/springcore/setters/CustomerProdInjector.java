package com.ford1.springcore.setters;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerProdInjector {

    ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/NewCustomerContext.xml");
    boolean flag = false;
    public boolean injectCustomer1NProducts1()
    {
        try {
            Customer customer1 = (Customer) context.getBean("customer1");
            customer1.displayCustomerDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }

    public boolean injectCustomer2NProducts2()
    {
        try {
            Customer customer2 = (Customer) context.getBean("customer2");
            customer2.displayCustomerDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
