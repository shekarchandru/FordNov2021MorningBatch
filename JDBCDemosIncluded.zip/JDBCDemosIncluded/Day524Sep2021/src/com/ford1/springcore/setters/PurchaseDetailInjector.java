package com.ford1.springcore.setters;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PurchaseDetailInjector {
    ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/PurchaseDetailsContext.xml");
    boolean flag = false;
    public boolean injectPurchaseDetail1()
    {
        try
        {
            PurchaseDetails purchase1 = (PurchaseDetails) context.getBean("purchaseDetail1");
            purchase1.displayPurchaseDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectPurchaseDetail2()
    {
        try
        {
            PurchaseDetails purchase2 = (PurchaseDetails) context.getBean("purchaseDetail2");
            purchase2.displayPurchaseDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
