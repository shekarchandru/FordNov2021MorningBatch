package com.ford1.springcore.setters;

public class CustomerNew {
    private String customerId;
    private String customerName;
    private float purchaseValue;

    public CustomerNew() {
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public float getPurchaseValue() {
        return purchaseValue;
    }

    public void setPurchaseValue(float purchaseValue) {
        this.purchaseValue = purchaseValue;
    }

    @Override
    public String toString() {
        return "CustomerNew{" +
                "customerId='" + customerId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", purchaseValue=" + purchaseValue +
                '}';
    }
}
