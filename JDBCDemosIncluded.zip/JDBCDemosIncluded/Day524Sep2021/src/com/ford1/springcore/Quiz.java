package com.ford1.springcore;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Quiz {
    String groupId;
    String topic;
    Map <String,String> questAns;

    public Quiz() {
    }

    public Quiz(String groupId, String topic, Map<String, String> questAns) {
        this.groupId = groupId;
        this.topic = topic;
        this.questAns = questAns;
    }

    public void displayQuizDetails()
    {
        System.out.println("The Quiz Details are ...");
        System.out.println("Quiz Group Id is :"+groupId);
        System.out.println("The Topic is :"+topic);
        System.out.println("the Question n Answers are ...");
        Set <Map.Entry <String,String>> entrySet = questAns.entrySet();

        Iterator <Map.Entry <String,String>> myEntries = entrySet.iterator();
        while(myEntries.hasNext())
        {
            Map.Entry <String,String> entry = myEntries.next();
            String question = entry.getKey();
            String answer = entry.getValue();
            System.out.println("The Question is :"+question);
            System.out.println("And The Answer is :"+answer);
            System.out.println("-----------------------------");
        }
    }
}
