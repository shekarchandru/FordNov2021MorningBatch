package ford3.morning.jdbc.service;

import ford3.morning.jdbc.model.Employee;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeServiceTest {
    EmployeeService employeeService ;
    List <Employee> expEmployees;
    Employee expEmp001;
    Employee empNew;
    Employee empUpdate;

    @BeforeEach
    void setUp() {
        employeeService = new EmployeeService();
        expEmployees = new ArrayList<Employee>();
        expEmployees.add(new Employee("E001", "Harsha", "RTNagar", "9488488488", 1000.0f, 12));
        expEmployees.add(new Employee("E002", "Suman", "JayaNagar", "9345688488", 1500.0f, 13));
        expEmployees.add(new Employee("E003", "Kishan", "RJNagar", "9486477488", 2000.0f, 13));
        expEmployees.add(new Employee("E004", "RajeshKumar", "RTNagar", "8678839933", 3500.0f, 15));
        expEmployees.add(new Employee("E006", "MaheshKumar", "Vijayanagar", "8399393939", 2500.0f, 12));
        //Expected Employee for getEmployeeByID
       expEmp001 = new Employee("E001", "Harsha", "RTNagar", "9488488488", 1000.0f, 12);

       //Record To Be Inserted
       empNew = new Employee("E007", "KrishnaPrasad", "Koramangala", "9488768488", 1200.0f, 13);
       //Record To Be Updated
       empUpdate = new Employee("E007", "Krishna", "WilsonGarden", "9488768488", 1200.0f, 13);

    }

    @AfterEach
    void tearDown() {
        employeeService = null;
    }

    @Test
    void shouldGetALlEmployeeRecords() {
        //Given as in SetUp
        //When
        List <Employee> actEmployees = employeeService.getALlEmployeeRecords();
        //Then
        assertEquals(expEmployees,actEmployees);
    }

    @Test
    void shouldGetEmployeeRecordById() {
        //Given as In SetUp plus the following
        String empId = "E001";
        //When
        Employee actEmp001 = employeeService.getEmployeeRecordById(empId);
        //Then
        assertEquals(expEmp001,actEmp001);
    }

    @Test
    void shouldInsertEmployeeRecord() {
        assertTrue(employeeService.insertEmployeeRecord(empNew));
    }

    @Test
    void shouldUpdateEmployeeRecord() {
        //Given as in SetUp Plus the following
        String empId = "E007";
        //Then
        assertTrue(employeeService.updateEmployeeRecord(empUpdate,empId));
    }

    @Test
    void shouldDeleteEmployeeRecordById() {

        String empId = "E007";
        assertTrue(employeeService.deleteEmployeeRecordById(empId));
    }
}