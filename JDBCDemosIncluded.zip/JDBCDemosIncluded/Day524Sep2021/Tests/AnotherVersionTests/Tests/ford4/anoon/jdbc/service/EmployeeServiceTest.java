package ford4.anoon.jdbc.service;

import ford4.anoon.jdbc.model.Employee;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeServiceTest {


    EmployeeService employeeService;
    List <Employee> expectedEmployees;
    Employee expEmployeeById008;
    Employee employeeInsert;
    Employee employeeUpdate;
    @BeforeEach
    void setUp() {
        employeeService = new EmployeeService();
        expectedEmployees = new ArrayList<Employee>();
        expectedEmployees.add(new Employee("E001","Harsha","RTNagar","9488488488",1000,	12));
        expectedEmployees.add(new Employee("E002","Suman","JayaNagar","9345688488",1500,	13));
        expectedEmployees.add(new Employee("E003","Kishan","RJNagar","9486477488",2000,	13));
        expectedEmployees.add(new Employee("E004","RajeshKumar","RTNagar","8678839933",3500,	15));
        expectedEmployees.add(new Employee("E006","MaheshKumar","Vijayanagar","8399393939",2500,	12));
        expectedEmployees.add(new Employee("E008","KiranKumar","Indiranagar","8299299292",2500,	14));
        expectedEmployees.add(new Employee("E009","Sumanth","KKNagar","892992929",15000,	15));

        expEmployeeById008 = new Employee("E008","KiranKumar","Indiranagar","8299299292",2500,	14);

        employeeInsert = new Employee("E010","SrithiKumar","Indiranagar","8299299292",2500,	14);

        employeeUpdate = new Employee("E010","SmrithiKumar","Koramangala","8299456292",2600,	15);

    }

    @AfterEach
    void tearDown() {
        employeeService = null;
    }

    @Test
    void shouldGetEmployeeRecords() {
        //Given AS In SetUp
        //When
        List <Employee> actualEmployees = employeeService.getEmployeeRecords();
        //Then
        assertEquals(expectedEmployees,actualEmployees);
    }

    @Test
    void shouldGetEmployeeRecordById() {
        //Given as in SetUp Plus
        String empId = "E008";
        //When
        Employee actEmployeeByIdE008 = employeeService.getEmployeeRecordById(empId);
        //Then
        assertEquals(expEmployeeById008,actEmployeeByIdE008);
    }

    @Test
    void shouldInsertEmployeeRecord() {
        //Given as in SetUp
        //when
        assertTrue(employeeService.insertEmployeeRecord(employeeInsert));
    }

    @Test
    void shouldUpdateEmployeeRecord() {
        //Given as In SetUp plus the following
        String empId = "E010";
        boolean expResult=true;
        //When
        boolean actResult = employeeService.updateEmployeeRecord(employeeUpdate,empId);
        //Then
        assertEquals(expResult,actResult);

    }

    @Test
    void deleteEmployeeRecordById() {
        //Given
        String empId = "E006";
        boolean expResult = true;
        //When
        boolean actResult = employeeService.deleteEmployeeRecordById(empId);
        //Then
        assertEquals(expResult,actResult);
    }

    @Test
    void getMaxEmployeeId() {
    }
}