package com.ford2.setter.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeAppraisalReportInjectorTest {
EmployeeAppraisalReportInjector employeeAppraisalReportInjector;
    @BeforeEach
    void setUp() {
        employeeAppraisalReportInjector = new EmployeeAppraisalReportInjector();
    }

    @AfterEach
    void tearDown() {
        employeeAppraisalReportInjector = null;
    }

    @Test
    void shouldInjectEmployee1() {

        assertTrue(employeeAppraisalReportInjector.injectEmployee1());
    }

    @Test
    void shouldInjectEmployee2() {
        assertTrue(employeeAppraisalReportInjector.injectEmployee2());
    }
}