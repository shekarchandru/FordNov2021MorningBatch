package com.ford.nov9.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SerializationSampleTest {

    SerializationSample serSample;
    @BeforeEach
    void setUp() {
        serSample = new SerializationSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldSerializeEmployees()
    {
        assertTrue(serSample.serializeObject());
    }
}