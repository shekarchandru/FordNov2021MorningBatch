package com.ford.nov9.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PrintWriterSampleTest {

    PrintWriterSample pwSample;
    @BeforeEach
    void setUp() {
        pwSample = new PrintWriterSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void writeThruPrintWriter() {
        assertTrue(pwSample.writeThruPrintWriter());
    }
}