package com.ford.nov11.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class QueueSampleTest {

    QueueSample queueSample;
    @BeforeEach
    void setUp() {
        queueSample = new QueueSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldFetchQueueElementsThruIterator()
    {
        assertTrue(queueSample.fetchQueueObjectsThruIterator());
    }
}