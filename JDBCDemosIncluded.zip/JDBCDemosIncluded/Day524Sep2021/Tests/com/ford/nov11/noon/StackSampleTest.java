package com.ford.nov11.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StackSampleTest {

    StackSample stackSample;
    @BeforeEach
    void setUp() {
        stackSample = new StackSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void fetchStackElementsThruPop() {
        assertTrue(stackSample.fetchStackElementsThruPop());
    }

    @Test
    void fetchStackElementsThruIterator() {
        assertTrue(stackSample.fetchStackElementsThruIterator());
    }
}