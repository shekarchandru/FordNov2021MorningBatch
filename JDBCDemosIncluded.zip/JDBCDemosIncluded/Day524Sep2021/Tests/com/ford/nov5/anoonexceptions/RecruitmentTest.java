package com.ford.nov5.anoonexceptions;

import com.ford.morn.nov05exceptions.InvalidAgeException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RecruitmentTest {

    Recruitment recruitment;
    @BeforeEach
    void setUp() {
        recruitment = new Recruitment();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldReturnTrueForValidAge() throws InvalidAgeException
    {
        //Given
        int age = 25;
        boolean expectedFlag = true;
        //When
        boolean actualFlag = recruitment.scrutinizeAge(age);//throw
        //Then
        assertEquals(expectedFlag,actualFlag);
    }
    @Test
    public void shouldReturnFalseForInValidAge() throws InvalidAgeException
    {
        //Given
        int age = 35;
        boolean expectedFlag = false;
        //When
        boolean actualFlag = recruitment.scrutinizeAge(age);//throw
        //Then
        assertEquals(expectedFlag,actualFlag);
    }

    @Test
    public void shouldThrowInvalidAgeException()
    {
        //Given
        int age = 32;
        //Then
      //  Exception exception = recruitment.scrutinizeAge(age);
        assertThrows(InvalidAgeException.class, () -> recruitment.scrutinizeAge(age));
    }

}