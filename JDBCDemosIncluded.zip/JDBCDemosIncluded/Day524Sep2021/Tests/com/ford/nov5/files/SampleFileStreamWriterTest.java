package com.ford.nov5.files;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SampleFileStreamWriterTest {

    SampleFileStreamWriter streamWriter;
    @BeforeEach
    void setUp() {
        streamWriter = new SampleFileStreamWriter();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldWriteToBinaryStream()
    {
        assertTrue(streamWriter.writeToFileStream());
    }

}