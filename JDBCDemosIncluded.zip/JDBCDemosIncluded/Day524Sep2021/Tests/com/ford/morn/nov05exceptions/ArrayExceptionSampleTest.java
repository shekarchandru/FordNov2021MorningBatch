package com.ford.morn.nov05exceptions;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Array;

import static org.junit.jupiter.api.Assertions.*;

class ArrayExceptionSampleTest {

    ArrayExceptionSample aSample;
    String[] countries = {"India","USA","UK","Japan","Australia"};
    String myIndex ;
    @BeforeEach
    void setUp() {
        aSample = new ArrayExceptionSample();

    }

    @AfterEach
    void tearDown() {
        aSample = null;
    }
    @Test
    public void shouldDisplayArrayForValidIndex()
    {
        //given
        boolean myflag = true;
        //when
        boolean hisflag = aSample.manipulateArray(9);
        //then
        assertEquals(myflag,hisflag);
    }
    @Test
    public void shouldDisplayArrayForInValidIndex()
    {
        //given
        boolean myflag = false;
        //when
        boolean hisflag = aSample.manipulateArray(11);
        //then
        assertFalse(aSample.manipulateArray(11));
    }
    @Test
    public void shouldThrowAnotherArrayIndexOutOfBoundsException()
    {
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> aSample.manipulateArray(11));
    }
    @Test
    public void shouldReturnMyCountry()
    {
        //Given
       // String[] countries = {"India","USA","UK","Japan","Australia"};
        myIndex = "3";
        //When
        String myCountryByIndex = aSample.getCountryByIndex(countries,myIndex);
        //Then
        assertEquals("Japan",myCountryByIndex);
    }
    @Test
    public void shouldThrowArrayIndexOutOfBoundsException()
    {
        //when
        myIndex = "6";
        //then
        assertThrows(ArrayIndexOutOfBoundsException.class,() -> aSample.getCountryByIndex(countries,myIndex));
    }
    @Test
    public void shouldThrowNumberFormatException()
    {
        //when
        myIndex = "two";
        //then
        assertThrows(NumberFormatException.class,() -> aSample.getCountryByIndex(countries,myIndex));
    }





}