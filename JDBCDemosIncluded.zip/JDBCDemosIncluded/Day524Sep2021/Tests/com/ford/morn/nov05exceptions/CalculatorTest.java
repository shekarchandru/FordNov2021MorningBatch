package com.ford.morn.nov05exceptions;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    Calculator calci;
    @BeforeEach
    void setUp() {
        calci = new Calculator();
    }

    @AfterEach
    void tearDown() {
        calci = null;
    }

    @Test
    public void shouldReturnTheDividend()
    {
        //given
        int resultExp = 2;
        //when
        int resultAct = calci.calculateDividend(200,100);
        //then
        assertEquals(resultExp,resultAct);
    }
}