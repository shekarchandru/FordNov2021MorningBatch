package com.ford.nov10.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class GenericArrayListSampleTest {

    GenericArrayListSample galSample;
    ArrayList <Customer> expectedCustomers;
    @BeforeEach
    void setUp() {
        galSample = new GenericArrayListSample();
        expectedCustomers = new ArrayList<Customer>();
        Customer c1 = new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1");
        expectedCustomers.add(c1);
        expectedCustomers.add(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        expectedCustomers.add(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        expectedCustomers.add(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        expectedCustomers.add(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));

    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldReturnCustomersFromGenericArrayList()
    {
        //Given: as in setUp

        //when
        ArrayList <Customer> actualCustomers = galSample.displayGenericArrayListElements();

        //Then
        assertEquals(expectedCustomers,actualCustomers);
    }
}