package com.ford.nov10.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LinkedListSampleTest {

    LinkedListSample llSample;
    @BeforeEach
    void setUp() {
        llSample = new LinkedListSample();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldDisplayLListCustomers()
    {
        assertTrue(llSample.displayLinkedListElements());
    }

    @Test
    public void shouldDisplayLListCustomersInReverse()
    {
        assertTrue(llSample.displayListCustomersInReverse());
    }

}