package com.ford.nov10.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArrayListSampleTest {

    ArrayListSample alSample;
    Customer expectedCustomer;
    @BeforeEach
    void setUp() {

        alSample = new ArrayListSample();
        expectedCustomer = new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3");
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldDisplayArrayListObjects()
    {
        assertTrue(alSample.fetchCustomersDataFromArrayList());
    }

    @Test
    public void shouldGetCustomerByIndex()
    {
        //given setUp plus following
        int myIndex = 2;
        //When
        Customer actualCustomer = alSample.getCustomerByIndex(myIndex);
        assertEquals(expectedCustomer,actualCustomer);

    }

}