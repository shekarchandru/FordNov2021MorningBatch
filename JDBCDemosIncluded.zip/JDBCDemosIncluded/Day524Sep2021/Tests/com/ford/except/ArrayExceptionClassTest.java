package com.ford.except;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArrayExceptionClassTest {
    ArrayIndexExceptionClass aiec;
    @BeforeEach
    void setUp() {
        aiec = new ArrayIndexExceptionClass();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldThrowArrayIndexOutOfBoundsException()
    {
        //Given
        String[] strArray = {"India","USA","Australia","Japan"};
        String index = "Five";
       // Exception exception = assertThrows(ArrayIndexOutOfBoundsException.class,() -> aiec.getValueFromIndex(strArray,index));
        Exception exception = assertThrows(NumberFormatException.class,() -> aiec.getValueFromIndex(strArray,index));

    }

}