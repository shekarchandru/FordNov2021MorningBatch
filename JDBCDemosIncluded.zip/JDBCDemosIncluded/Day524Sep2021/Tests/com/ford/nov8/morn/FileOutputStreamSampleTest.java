package com.ford.nov8.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FileOutputStreamSampleTest {

    FileOutputStreamSample fileSample;
    @BeforeEach
    void setUp() {
        fileSample = new FileOutputStreamSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldWriteToBinaryStream()
    {
        assertTrue(fileSample.writeToStream());
    }

}