package com.ford1.springcorenoon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QuestAnswerInjectorTest {

    QuestAnswerInjector questAnswerInjector;
    @BeforeEach
    void setUp() {
        questAnswerInjector = new QuestAnswerInjector();
    }

    @AfterEach
    void tearDown() {
        questAnswerInjector = null;
    }

    @Test
    void shouldInjectQuestionAndAnswer1() {
        assertTrue(questAnswerInjector.injectQuestionAndAnswer1());
    }

    @Test
    void shouldInjectQuestionAndAnswer2() {
        assertTrue(questAnswerInjector.injectQuestionAndAnswer2());
    }
}