package com.ford1.springcorenoon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerInjectorTest {

    CustomerInjector customerInjector;
    @BeforeEach
    void setUp() {
        customerInjector = new CustomerInjector();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void shouldInjectCustomerNProducts() {
        assertTrue(customerInjector.injectCustomerNProducts());
    }
}