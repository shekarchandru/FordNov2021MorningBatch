package com.ford1.springcore.setters;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PurchaseDetailInjectorTest {

    PurchaseDetailInjector purchaseDetailInjector;
    @BeforeEach
    void setUp() {
        purchaseDetailInjector = new PurchaseDetailInjector();
    }

    @AfterEach
    void tearDown() {
        purchaseDetailInjector = null;
    }

    @Test
    void shouldInjectPurchaseDetail1() {
        assertTrue(purchaseDetailInjector.injectPurchaseDetail1());
    }

    @Test
    void shouldInjectPurchaseDetail2() {
        assertTrue(purchaseDetailInjector.injectPurchaseDetail2());
    }
}