import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class CalculatorTest {
static Calculator calci;
    @BeforeAll
    public static void setUp()
    {
        calci = new Calculator();
    }



 @Test
    public void divideTest1() {
        Exception exception = assertThrows(ArithmeticException.class, () ->
                calci.divide(1, 0));
        assertEquals("/ by zero", exception.getMessage());
    }   /**/
    @Test
    public void divideTest() throws ArrayIndexOutOfBoundsException{
        Exception exception;
        exception = assertThrows(ArrayIndexOutOfBoundsException.class,
                () ->
                        calci.manipulateArrray());
        //assertEquals("/ by zero", exception.getMessage());
    }
}