package com.ford.model;

public class Supplier {

	String supplierId;
	String supplierName;
	String supplierAddress;
	int supplyAmount;
	
	
	
	public Supplier() {
		super();
	}



	public Supplier(String supplierId, String supplierName, String supplierAddress, int supplyAmount) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.supplierAddress = supplierAddress;
		this.supplyAmount = supplyAmount;
	}



	public String getSupplierId() {
		return supplierId;
	}



	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}



	public String getSupplierName() {
		return supplierName;
	}



	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}



	public String getSupplierAddress() {
		return supplierAddress;
	}



	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}



	public int getSupplyAmount() {
		return supplyAmount;
	}



	public void setSupplyAmount(int supplyAmount) {
		this.supplyAmount = supplyAmount;
	}



	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", supplierName=" + supplierName + ", supplierAddress="
				+ supplierAddress + ", supplyAmount=" + supplyAmount + "]";
	}
	
	
}
