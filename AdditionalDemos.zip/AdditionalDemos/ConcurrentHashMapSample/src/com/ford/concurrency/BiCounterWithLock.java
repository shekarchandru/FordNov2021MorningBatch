package com.ford.concurrency;

public class BiCounterWithLock {

	private int i = 0;
	private int j = 0;
	
	public int getI() {
		return i;
	}

	public void setJ(int j) {
		this.j = j;
	}
	public int getJ() {
		return j;
	}

	public void setI(int i) {
		this.i = i;
	}
	
	/*synchronized*/ public void incrementI()
	{
		i++;
		//get i
		//increment
		//set i
		// when multiple thread access
		// this increment function
	}
	/*synchronized*/ public void incrementJ()
	{
		j++;
		//get i
		//increment
		//set i
		// when multiple thread access
		// this increment function
	}
}
