package com.ford.concurrency;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BiCounter {

	/* 
	 * When Synchronized even if we have two different 
	 * data/functions, only one thread can access either of them , but when we have
	 * dif locks two threads can access 2 different functions 
	 * */
	private int i = 0;
	private int j = 0;
	
	Lock lockForI = new ReentrantLock();
	Lock lockForJ = new ReentrantLock();
	public int getI() {
		return i;
	}

	public void setJ(int j) {
		this.j = j;
	}
	public int getJ() {
		return j;
	}

	public void setI(int i) {
		this.i = i;
	}
	
	/*synchronized*/ public void incrementI()
	{
		//Get Lock For I
		lockForI.lock();
		i++;
		//process
		lockForI.unlock();
		//Release Lock
		
		//get i
		//increment
		//set i
		// when multiple thread access
		// this increment function
	}
	/*synchronized*/ public void incrementJ()
	{
		//Get Lock For J
		lockForJ.lock();
		j++;
		lockForJ.unlock();
		//Release Lock For J
		
		//get i
		//increment
		//set i
		// when multiple thread access
		// this increment function
	}
	
}
