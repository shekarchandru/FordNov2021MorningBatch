package com.ford.concurrency;

public class Counter {

	private int i = 0;
	
	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}
	
	/*synchronized*/ public void increment()
	{
		i++;
		//get i
		//increment
		//set i
		// when multiple thread access
		// this increment function
	}
}
