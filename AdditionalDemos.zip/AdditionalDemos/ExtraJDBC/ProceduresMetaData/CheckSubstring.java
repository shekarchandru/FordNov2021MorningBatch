
public class CheckSubstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "E009";
		
		String preStr = str.substring(0,1);
		String postStr = str.substring(1,str.length());
		System.out.println(preStr);
		System.out.println(postStr);
	}

}
