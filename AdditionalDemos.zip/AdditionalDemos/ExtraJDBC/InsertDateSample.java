import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InsertDateSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=	DriverManager.getConnection("jdbc:mysql://localhost:3306/ctsdata", "root", "MySQL_@123456");
		PreparedStatement pstmt = con.prepareStatement("insert into Agent values(?,?)");
		pstmt.setString(1,"A002");
		Date dt1 = stringToDateConverter("2021-05-21");
		pstmt.setDate(2, utilToSqlDateConverter(dt1));
		
		pstmt.execute();
		System.out.println("inserted SUccessfully...");
		}
		catch(ClassNotFoundException sqe)
		{
			sqe.printStackTrace();
		}
		catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		
		
	
		
	}

	public static java.util.Date stringToDateConverter(String stringDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(stringDate);
		} catch (ParseException pe) {
			return null;
		}
	}
	public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
		java.sql.Date sqlDate = null;
		if (utDate != null) {
			sqlDate = new java.sql.Date(utDate.getTime());
		}
		return sqlDate;
	}
}
