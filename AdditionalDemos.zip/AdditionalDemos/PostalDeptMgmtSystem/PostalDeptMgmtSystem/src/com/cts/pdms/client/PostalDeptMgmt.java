package com.cts.pdms.client;


import com.cts.pdms.exception.PostalDeptMgmtException;
import com.cts.pdms.service.PostalDeptMgmtService;

public class PostalDeptMgmt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PostalDeptMgmtService postService = new PostalDeptMgmtService();
		try 
		{
			postService.addNSCHolderDetails("C:\\Training2020-21\\Demos\\PostalDeptMgmtSystem\\PostalDeptMgmtSystem\\src\\inputFeed.txt");
		} catch (PostalDeptMgmtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
