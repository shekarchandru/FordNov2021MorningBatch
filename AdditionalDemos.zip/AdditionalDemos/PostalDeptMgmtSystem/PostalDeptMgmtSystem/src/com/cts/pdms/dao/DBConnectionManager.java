package com.cts.pdms.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cts.pdms.exception.PostalDeptMgmtException;

public class DBConnectionManager {

	 
	 private static Connection con = null;
	 private static DBConnectionManager instance;
	public  DBConnectionManager()  throws PostalDeptMgmtException
	{
		FileInputStream fis=null;
		 
		try 
		{
			fis = new FileInputStream("C:\\Training2020-21\\Demos\\PostalDeptMgmtSystem\\PostalDeptMgmtSystem\\src\\database.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
        Properties p=new Properties (); 
        try 
        {
			p.load (fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
        String dname= (String) p.get ("drivername"); 
        String url= (String) p.get ("url"); 
        String username= (String) p.get ("username"); 
        String password= (String) p.get ("password"); 
        try 
        {
			Class.forName(dname);
		} 
        catch (ClassNotFoundException e) {
			throw new PostalDeptMgmtException("Driver class not found", e.getCause());
		} 
        	
		
		try 
		{
			con = DriverManager.getConnection( url, username, password);
		}  
		catch (SQLException e) {
			throw new PostalDeptMgmtException("Unable to establish DB connection ", e.getCause());
		}
		
        //return con;
	}
	public static DBConnectionManager getInstance() throws PostalDeptMgmtException {
		try {
			if ((instance == null) || (instance.getConnection().isClosed())) {
				instance = new DBConnectionManager();
			}
		} catch (SQLException e) {
			throw new PostalDeptMgmtException("Unable to establish DB connection ", e.getCause());
		}

		return instance;
	}
	public Connection getConnection() {
		return con;
	}
}
