package com.cts.pdms.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cts.pdms.dao.DBConnectionManager;
import com.cts.pdms.exception.PostalDeptMgmtException;

class DBConnectionManagerTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

/*	@Test
	void testDBConnectionManager() {
		fail("Not yet implemented");
	}

	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}*/

	@Test
	void testGetConnection() {
		try {
			assertNotNull(DBConnectionManager.getInstance().getConnection());
		} catch (PostalDeptMgmtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
