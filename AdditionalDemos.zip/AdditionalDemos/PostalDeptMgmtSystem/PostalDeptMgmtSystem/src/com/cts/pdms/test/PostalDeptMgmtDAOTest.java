package com.cts.pdms.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cts.pdms.dao.PostalDeptMgmtDAO;
import com.cts.pdms.exception.PostalDeptMgmtException;
import com.cts.pdms.model.NSCHolderDetail;
import com.cts.pdms.util.ApplicationUtil;



class PostalDeptMgmtDAOTest {

	private PostalDeptMgmtDAO postalDtMgmtDao;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		postalDtMgmtDao = new PostalDeptMgmtDAO();
	}

	@AfterEach
	void tearDown() throws Exception {
		postalDtMgmtDao = null;
	}

	@Test
	void testInsertNSCHolderDetails() {
		ArrayList <NSCHolderDetail> nscHolderList = new ArrayList<NSCHolderDetail> ();
		String[] nscNos = {"nsc01","nsc02","nsc03","nsc04","nsc50"};
		nscHolderList.add(new NSCHolderDetail("R001", "C001", "Girish Kumar", "9838838883","Giri@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),1000,50, 50000, 45305, 2265.25,93039.75));
		nscHolderList.add(new NSCHolderDetail("R002", "C002", "Mahesh Kumar", "9837468883","Mah@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),5000,5, 25000, 23559, 1178,47381));
		nscHolderList.add(new NSCHolderDetail("R003", "C003", "Rakesh Kumar", "9838647783","Rak@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),10000,5, 50000, 45305, 2265.25,93039.75));
		nscHolderList.add(new NSCHolderDetail("R004", "C004", "Rajesh Kumar", "9534638883","Raj@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),10000,5, 50000, 45305, 2265.25,93039.75));
		nscHolderList.add(new NSCHolderDetail("R005", "C005", "Milind Kumar", "9838887653","Mili@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),5000,5,  25000, 23559, 1178,47381));
		nscHolderList.add(new NSCHolderDetail("R006", "C006", "Kiran Kumar", "8374838883","Kir@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),5000,10, 50000, 45305, 2265.25,93039.75));
		
		try {
			assertTrue(postalDtMgmtDao.insertNSCHolderDetails(nscHolderList));
		} catch (PostalDeptMgmtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*@Test
	void testGetNSCHolderData() {
		fail("Not yet implemented");
	}*/

}
