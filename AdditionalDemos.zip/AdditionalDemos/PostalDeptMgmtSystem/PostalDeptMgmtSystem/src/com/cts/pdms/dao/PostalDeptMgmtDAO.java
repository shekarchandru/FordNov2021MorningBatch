package com.cts.pdms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cts.pdms.exception.PostalDeptMgmtException;
import com.cts.pdms.model.NSCHolderDetail;
import com.cts.pdms.util.ApplicationUtil;

public class PostalDeptMgmtDAO {

	//List <String> nscHolderList

	public static Connection connection = null;

	public boolean insertNSCHolderDetails(ArrayList <NSCHolderDetail> nscHolders) throws PostalDeptMgmtException {
		boolean recordsAdded = false;
		PreparedStatement nscHolderInsert = null;

		connection = DBConnectionManager.getInstance().getConnection();

		try {
			connection.setAutoCommit(false);

			nscHolderInsert = connection.prepareStatement("INSERT INTO NSCHolderDetails  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			for (NSCHolderDetail nscHolder : nscHolders) {
//nsc01;nsc02
				nscHolderInsert.setString(1, nscHolder.getRecordId());
				nscHolderInsert.setString(2, nscHolder.getCustomerId());
				nscHolderInsert.setString(3, nscHolder.getCustomerName());
				
				nscHolderInsert.setString(4, nscHolder.getCustomerPhone());
				nscHolderInsert.setString(5,nscHolder.getCustomereMail());
				String[] nscIds = nscHolder.getNSCidNos();
				StringBuffer sbrNSCIds = new StringBuffer();
				for(int i=0;i<nscIds.length;i++)
				{
					sbrNSCIds.append(nscIds[i]);
					sbrNSCIds.append(";");
				}//nsc01;nsc02;nsc03
				String strSbrNSCIds = new String(sbrNSCIds);
				nscHolderInsert.setString(6,strSbrNSCIds);
				
				nscHolderInsert.setDate(7, ApplicationUtil.utilToSqlDateConverter(nscHolder.getDateOfIssue()));
				nscHolderInsert.setDate(8, ApplicationUtil.utilToSqlDateConverter(nscHolder.getMaturityDate()));
				
				nscHolderInsert.setInt(9, nscHolder.getDenomination());
				nscHolderInsert.setInt(10, nscHolder.getNoOfCertificates());
				
				nscHolderInsert.setFloat(11, Float.parseFloat(new Double(nscHolder.getTotalCost()).toString()));
				nscHolderInsert.setFloat(12, Float.parseFloat(new Double(nscHolder.getInterestAccumulated()).toString()));
				nscHolderInsert.setFloat(13, Float.parseFloat(new Double(nscHolder.getTaxDeductionOnInterest()).toString()));
				nscHolderInsert.setFloat(14, Float.parseFloat(new Double(nscHolder.getNettAmtPayable()).toString()));
			
				nscHolderInsert.addBatch();

			}

			int[] rowsAdded = nscHolderInsert.executeBatch();

			if (rowsAdded != null && rowsAdded.length > 0) {
				recordsAdded = true;
			}
			connection.commit();

		} catch (SQLException e) {

			if (connection != null) {
				try {
					connection.rollback();
				} catch (SQLException se) {
					throw new PostalDeptMgmtException(se.getMessage(), se.getCause());
				}
			}

		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					throw new PostalDeptMgmtException(e.getMessage(), e.getCause());
				}
			}
		}

		return recordsAdded;
	}
	public ArrayList <NSCHolderDetail> getNSCHolderData()
	{
		ArrayList <NSCHolderDetail> nscHolderDetails = new ArrayList<NSCHolderDetail>();
		
		
		return nscHolderDetails;
	}
}
