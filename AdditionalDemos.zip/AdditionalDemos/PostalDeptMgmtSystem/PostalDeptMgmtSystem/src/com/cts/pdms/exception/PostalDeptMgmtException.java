package com.cts.pdms.exception;

public class PostalDeptMgmtException extends Exception{
	
String strMsg1;
Throwable strMsg2;


public PostalDeptMgmtException() {
	super();
}


public PostalDeptMgmtException(String strMsg1, Throwable strMsg2) {
	super();
	this.strMsg1 = strMsg1;
	this.strMsg2 = strMsg2;
}


}
