package com.cts.pdms.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import com.cts.pdms.exception.PostalDeptMgmtException;

public class ApplicationUtil {
	public static List<String> readFile(String inputfeed) throws PostalDeptMgmtException {
		List <String> nscHolderList = new ArrayList <String> ();
		if (inputfeed != null) {
			String line = "";  
			String splitBy = ",";  
			try
			{
			//FileInputStream f= new FileInputStream(inputfeed);
			FileInputStream f= new FileInputStream("C:\\Training2020-21\\Demos\\PostalDeptMgmtSystem\\PostalDeptMgmtSystem\\src\\inputFeed.txt");
	        BufferedReader br = new BufferedReader(new InputStreamReader(f));
	        String strline;
	       StringBuffer sb = new StringBuffer();
	 //R006,C006,Kiran Kumar,8374838883,Kir@gmail.com,nsc01;nsc02;nsc03;nsc04;nsc05,ApplicationUtil.stringToDateConverter("2015-05-26"),ApplicationUtil.stringToDateConverter("2020-05-26"),5000,10,50000,45305,2265.25,93039.75     
	        while ((strline = br.readLine()) != null)
	        {
	        //	System.out.println(strline);
	        //	System.out.println("reading..");
	        	  StringTokenizer strTok = new StringTokenizer(strline);
	           // String[] arraylist=StringUtils.split(strline, ",");
	        	  String[] arraylist=strline.split(",");
	        	 //arryaList[0]=
	        	/*  for(int i=0;i<arraylist.length;i++)
	        	  {
	        		  System.out.println(arraylist[i]);
	        	  }*/
	        	 // System.out.println(arraylist);
	        	int len = arraylist.length;
	        
	        	Date dateOfMaturity = new Date();
	        	dateOfMaturity = stringToDateConverter(arraylist[7]);
	        	System.out.println(dateOfMaturity);
	        	
	        	boolean eligible = checkIfMaturesThisMonth(dateOfMaturity); 
	            if(eligible)
	            {
	            	nscHolderList.add(strline);
	            }
	          //  System.out.println(nscHolderList);
	        }
	      //  System.out.println("Data: "+sb.toString());
			}
			catch(FileNotFoundException fnfe)
			{
				fnfe.printStackTrace();
			}
			catch(IOException ioe)
			{
				ioe.printStackTrace();
			}
		}

		return nscHolderList;
	}
	public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
		java.sql.Date sqlDate = null;
		if (utDate != null) {
			sqlDate = new java.sql.Date(utDate.getTime());
		}
		return sqlDate;
	}
	
	public static java.util.Date stringToDateConverter(String stringDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(stringDate);
		} catch (ParseException pe) {
			return null;
		}
	}
	public static boolean checkIfMaturesThisMonth(Date maturityDate)
	{
		// Checks if the month of maturityDate and month of currentDate are same
		// Assumption is all NSCs mature on 30th or 31st of any month
		//we will fill this later...
		return true;
	}
}

