package com.cts.pdms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cts.pdms.exception.PostalDeptMgmtException;
import com.cts.pdms.model.NSCHolderDetail;
import com.cts.pdms.util.ApplicationUtil;

public class PostalDeptMgmtDAO {

	

	public static Connection connection = null;

	public boolean insertNSCHolderDetails(ArrayList <NSCHolderDetail> nscHolders) throws PostalDeptMgmtException {
		boolean recordsAdded = false;
		PreparedStatement nscHolderInsert = null;

		
		return recordsAdded;
	}
	public ArrayList <NSCHolderDetail> getNSCHolderData()
	{
		ArrayList <NSCHolderDetail> nscHolderDetails = new ArrayList<NSCHolderDetail>();
		
		
		return nscHolderDetails;
	}
}
